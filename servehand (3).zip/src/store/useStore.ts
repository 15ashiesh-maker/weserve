import { create } from 'zustand';

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  city?: string;
  role?: 'user' | 'maid' | 'admin';
  onboardingCompleted?: boolean;
  currentAddress?: string;
  permanentAddress?: string;
  aadharNumber?: string;
  familyDetails?: string;
  photoUrl?: string;
  documentUrl?: string;
  policeVerificationUrl?: string;
  verificationStatus?: Record<string, 'not_uploaded' | 'pending' | 'verified' | 'rejected'>;
  documentUrls?: Record<string, string>;
  notificationPreferences?: {
    pushNotifications: boolean;
    emailAlerts: boolean;
  };
  averageRating?: number;
  reviewCount?: number;
}

export interface Review {
  id: string;
  bookingId: string;
  customerId: string;
  customerName: string;
  maidId: string;
  rating: number; // 1-5
  comment: string;
  createdAt: string;
}

export interface Booking {
  id: string;
  service: string;
  date: string;
  time: string;
  address: string;
  status: 'pending' | 'confirmed' | 'upcoming' | 'completed' | 'cancelled';
  amount: number;
  createdAt: string;
  userId: string;
  estimatedArrival?: string;
  maidId?: string;
  customerName?: string;
}

interface AppState {
  user: User | null;
  bookings: Booking[];
  setUser: (user: User | null) => void;
  setBookings: (bookings: Booking[]) => void;
  logout: () => void;
}

export const useStore = create<AppState>()((set) => ({
  user: null,
  bookings: [],
  setUser: (user) => set({ user }),
  setBookings: (bookings) => set({ bookings }),
  logout: () => set({ user: null, bookings: [] }),
}));

