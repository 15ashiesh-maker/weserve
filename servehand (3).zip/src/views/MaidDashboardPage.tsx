'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calendar, 
  DollarSign, 
  User, 
  FileText, 
  Clock, 
  CheckCircle, 
  XCircle, 
  Settings, 
  LogOut, 
  ChevronRight, 
  Star,
  Shield,
  Bell,
  Wallet,
  MapPin,
  Search,
  ArrowRight
} from 'lucide-react';
import { useStore, Booking } from '../store/useStore';
import { useRouter } from 'next/navigation';
import Footer from '../components/layout/Footer';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';

import { collection, query, where, onSnapshot, orderBy, doc, updateDoc } from 'firebase/firestore';
import { signOut } from 'firebase/auth';
import { db, auth, handleFirestoreError } from '../lib/firebase';

const MaidDashboardPage = () => {
  const { user, setUser } = useStore();
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<'tasks' | 'browse' | 'payments' | 'history' | 'profile' | 'documents'>('tasks');
  
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [bookingFilter, setBookingFilter] = useState<'available' | 'tasks' | 'past'>('available');
  const [uploadingDoc, setUploadingDoc] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // Local state for profile fields
  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    phone: user?.phone || '',
    aadharNumber: user?.aadharNumber || '',
    city: user?.city || '',
    currentAddress: user?.currentAddress || '',
    familyDetails: user?.familyDetails || ''
  });

  useEffect(() => {
    if (!user?.id || user.role !== 'maid') return;
    
    // Fetch available bookings (pending)
    const qPending = query(
      collection(db, 'bookings'),
      where('status', '==', 'pending'),
      orderBy('date', 'desc')
    );
    
    // Fetch assigned tasks
    const qAssigned = query(
      collection(db, 'bookings'),
      where('maidId', '==', user.id),
      orderBy('date', 'desc')
    );
    
    const unsubPending = onSnapshot(qPending, (snapshot) => {
      const pendingJobs = snapshot.docs.map(d => ({ id: d.id, ...d.data() }) as Booking);
      setBookings(prev => {
        const assigned = prev.filter(b => b.maidId === user.id);
        return [...assigned, ...pendingJobs].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      });
    });

    const unsubAssigned = onSnapshot(qAssigned, (snapshot) => {
      const assignedTasks = snapshot.docs.map(d => ({ id: d.id, ...d.data() }) as Booking);
      setBookings(prev => {
        const pending = prev.filter(b => b.status === 'pending');
        return [...assignedTasks, ...pending].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      });
    });

    return () => {
      unsubPending();
      unsubAssigned();
    };
  }, [user?.id]);


  if (!user || user.role !== 'maid') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-soft-bg">
        <button onClick={() => router.push('/login')} className="px-6 py-2 bg-primary text-white rounded">Login</button>
      </div>
    );
  }

  // Auto-redirect to onboarding if not completed
  if (!user.onboardingCompleted) {
    router.push('/onboarding');
    return null;
  }

  const stats = [
    { label: 'Total Earnings', value: '₹0', icon: Wallet, color: 'text-orange-600', bg: 'bg-orange-100' },
    { label: 'Active Bookings', value: bookings.filter(b => b.maidId === user.id && b.status !== 'completed').length.toString(), icon: Calendar, color: 'text-purple-600', bg: 'bg-purple-100' },
    { label: 'Avg Rating', value: '0.0', icon: Star, color: 'text-orange-500', bg: 'bg-orange-50' },
    { label: 'Comp. Jobs', value: bookings.filter(b => b.maidId === user.id && b.status === 'completed').length.toString(), icon: CheckCircle, color: 'text-purple-600', bg: 'bg-purple-100' },
  ];

  const handleDocumentUpload = async (e: React.ChangeEvent<HTMLInputElement>, docType: string) => {
    if (!user || !e.target.files?.[0]) return;
    const file = e.target.files[0];
    setUploadingDoc(docType);
    
    try {
      // Simulation of upload delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const userRef = doc(db, 'users', user.id);
      
      const updateData: any = {
        [`verificationStatus.${docType}`]: 'pending',
        [`documentUrls.${docType}`]: `${file.name}_mock_url`
      };
      
      await updateDoc(userRef, updateData);
      
      setUser({
        ...user,
        verificationStatus: {
          ...(user.verificationStatus || {}),
          [docType]: 'pending'
        },
        documentUrls: {
          ...(user.documentUrls || {}),
          [docType]: `${file.name}_mock_url`
        }
      });
      
      alert(`${docType} uploaded successfully and is now under review.`);
    } catch (error) {
      console.error(error);
      alert('Failed to upload document.');
    } finally {
      setUploadingDoc(null);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    setUser(null);
    router.push('/');
  };

  const acceptJob = async (bookingId: string) => {
    try {
      const bookingRef = doc(db, 'bookings', bookingId);
      await updateDoc(bookingRef, {
        status: 'confirmed',
        maidId: user.id
      });
    } catch (error) {
      console.error(error);
      alert('Failed to accept job.');
    }
  };

  const completeJob = async (bookingId: string) => {
    try {
      const bookingRef = doc(db, 'bookings', bookingId);
      await updateDoc(bookingRef, {
        status: 'completed'
      });
    } catch (error) {
      console.error(error);
      alert('Failed to complete job.');
    }
  };

  const handleSaveProfile = async () => {
    if (!user) return;
    setIsSaving(true);
    try {
      const userRef = doc(db, 'users', user.id);
      await updateDoc(userRef, {
        name: profileData.name,
        phone: profileData.phone,
        aadharNumber: profileData.aadharNumber,
        city: profileData.city,
        currentAddress: profileData.currentAddress,
        familyDetails: profileData.familyDetails
      }).catch(err => handleFirestoreError(err, 'update', `users/${user.id}`, auth.currentUser));
      
      setUser({
        ...user,
        ...profileData
      });
      alert('Profile updated successfully!');
    } catch (error) {
      console.error(error);
      alert('Failed to update profile.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-soft-bg pt-20">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-[40px] p-8 shadow-xl border border-gray-50 flex flex-col items-center sticky top-24">
              <div className="w-24 h-24 bg-primary rounded-full flex items-center justify-center text-white text-3xl font-bold mb-4 shadow-lg ring-4 ring-primary/10">
                {user.name.charAt(0)}
              </div>
              <h2 className="text-xl font-display font-bold text-secondary mb-1">{user.name}</h2>
              <div className="flex items-center gap-1 text-orange-500 font-bold mb-8">
                <Star size={16} fill="currentColor" />
                <span>4.8 (42 Reviews)</span>
              </div>

              <div className="w-full space-y-2">
                {[
                  { id: 'tasks', label: 'My Tasks', icon: CheckCircle },
                  { id: 'browse', label: 'Find Jobs', icon: Search },
                  { id: 'history', label: 'Work History', icon: Clock },
                  { id: 'payments', label: 'Earnings', icon: DollarSign },
                  { id: 'profile', label: 'Profile', icon: User },
                  { id: 'documents', label: 'Documents', icon: FileText }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id as any)}
                    className={`w-full flex items-center justify-between px-6 py-4 rounded-2xl font-bold transition-all duration-300 ${
                      activeTab === item.id 
                        ? 'bg-primary text-white shadow-lg shadow-primary/25 scale-[1.02]' 
                        : 'text-text-muted hover:bg-soft-bg hover:text-primary'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <item.icon size={20} />
                      <span>{item.label}</span>
                    </div>
                    <ChevronRight 
                      size={16} 
                      className={`transition-all duration-300 ${activeTab === item.id ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-2'}`} 
                    />
                  </button>
                ))}

                <div className="pt-8 mt-8 border-t border-gray-50 w-full">
                  <button 
                    onClick={handleLogout}
                    className="w-full flex items-center justify-between px-6 py-4 rounded-2xl font-bold text-red-500 hover:bg-red-50 transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <LogOut size={20} />
                      <span>Logout</span>
                    </div>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Header Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {stats.map((stat, idx) => (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  key={idx}
                  className="bg-white p-6 rounded-[32px] shadow-lg border border-gray-50 flex flex-col items-center text-center hover:shadow-xl transition-shadow"
                >
                  <div className={`w-12 h-12 ${stat.bg} ${stat.color} rounded-2xl flex items-center justify-center mb-3`}>
                    <stat.icon size={24} />
                  </div>
                  <span className="text-secondary font-bold text-2xl">{stat.value}</span>
                  <p className="text-text-muted text-xs font-bold uppercase tracking-wider">{stat.label}</p>
                </motion.div>
              ))}
            </div>

            <div className="bg-white rounded-[40px] shadow-2xl border border-gray-50 overflow-hidden min-h-[600px]">
              <AnimatePresence mode="wait">
                {activeTab === 'tasks' && (
                  <motion.div
                    key="tasks"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="p-8 md:p-12"
                  >
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
                      <h3 className="text-3xl font-display font-bold text-secondary">Active Tasks</h3>
                      <Badge variant="outline" className="bg-purple-100 text-purple-600 border-none font-bold">
                        {bookings.filter(b => b.status === 'confirmed' && b.maidId === user.id).length} Assigned
                      </Badge>
                    </div>

                    <div className="space-y-4">
                      {bookings
                        .filter(b => b.status === 'confirmed' && b.maidId === user.id)
                        .map((booking) => (
                        <div key={booking.id} className="p-6 rounded-3xl border-2 border-gray-50 hover:border-primary/20 transition-all group relative overflow-hidden">
                          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                            <div className="flex items-center gap-4">
                              <div className="w-16 h-16 bg-soft-bg rounded-2xl flex items-center justify-center text-primary text-2xl group-hover:bg-primary/5 transition-colors">
                                {booking.service.includes('Cook') ? '🍳' : '🧹'}
                              </div>
                              <div>
                                <h4 className="font-bold text-secondary text-lg">
                                  {booking.service}
                                </h4>
                                <div className="flex items-center gap-1 text-text-muted text-sm font-medium">
                                  <MapPin size={14} />
                                  <span className="truncate max-w-[200px]">{booking.address}</span>
                                </div>
                              </div>
                            </div>
                            
                            <div className="flex flex-wrap items-center gap-6">
                              <div className="flex items-center gap-2">
                                <Calendar size={18} className="text-primary" />
                                <span className="font-bold text-secondary text-sm">{booking.date}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Clock size={18} className="text-primary" />
                                <div className="flex flex-col">
                                  <span className="font-bold text-secondary text-sm">{booking.time}</span>
                                  {booking.estimatedArrival && (
                                    <span className="text-[10px] text-primary font-bold">Arrival: {booking.estimatedArrival}</span>
                                  )}
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center justify-between md:justify-end gap-6 w-full md:w-auto border-t md:border-t-0 pt-4 md:pt-0">
                              <div className="flex flex-col items-end">
                                <span className="text-sm font-bold text-text-muted uppercase tracking-widest leading-none mb-1">Fee</span>
                                <span className="text-xl font-bold font-display text-primary leading-none">₹{booking.amount}</span>
                              </div>
                              <div className="px-4 py-2 rounded-xl font-bold text-xs uppercase tracking-wider bg-purple-50 text-purple-600">
                                {booking.status}
                              </div>
                            </div>
                          </div>
                          
                          <div className="mt-6 pt-6 border-t border-gray-50">
                            <button 
                              onClick={() => completeJob(booking.id)}
                              className="w-full bg-green-600 text-white py-3 rounded-xl font-bold shadow-lg shadow-green-600/20 hover:scale-[1.01] active:scale-95 transition-all flex items-center justify-center gap-2"
                            >
                              <CheckCircle size={18} />
                              Mark as Completed
                            </button>
                          </div>
                        </div>
                      ))}
                      {bookings.filter(b => b.status === 'confirmed' && b.maidId === user.id).length === 0 && (
                        <div className="text-center py-24 bg-soft-bg rounded-[40px] border-2 border-dashed border-gray-200">
                          <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm">
                            <CheckCircle className="text-gray-300" size={32} />
                          </div>
                          <p className="text-text-muted font-bold text-lg mb-2">No active tasks</p>
                          <p className="text-text-muted/60 max-w-xs mx-auto mb-6">Browse available jobs in your area to find new work opportunities!</p>
                          <Button 
                            variant="default" 
                            onClick={() => setActiveTab('browse')}
                            className="bg-primary text-white px-8 py-6 rounded-2xl font-bold shadow-lg shadow-primary/20 hover:scale-105 active:scale-95 transition-all"
                          >
                            Browse Jobs <ArrowRight className="ml-2" size={18} />
                          </Button>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}

                {activeTab === 'browse' && (
                  <motion.div
                    key="browse"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="p-8 md:p-12"
                  >
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
                      <h3 className="text-3xl font-display font-bold text-secondary">Available Jobs</h3>
                      <Badge variant="outline" className="bg-orange-100 text-orange-600 border-none font-bold">
                        {bookings.filter(b => b.status === 'pending').length} New Requests
                      </Badge>
                    </div>

                    <div className="space-y-4">
                      {bookings
                        .filter(b => b.status === 'pending')
                        .map((booking) => (
                        <div key={booking.id} className="p-6 rounded-3xl border-2 border-gray-50 hover:border-primary/20 transition-all group relative overflow-hidden">
                          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                            <div className="flex items-center gap-4">
                              <div className="w-16 h-16 bg-soft-bg rounded-2xl flex items-center justify-center text-primary text-2xl group-hover:bg-primary/5 transition-colors">
                                {booking.service.includes('Cook') ? '🍳' : '🧹'}
                              </div>
                              <div>
                                <h4 className="font-bold text-secondary text-lg">
                                  {booking.service}
                                </h4>
                                <div className="flex items-center gap-1 text-text-muted text-sm font-medium">
                                  <MapPin size={14} />
                                  <span className="truncate max-w-[200px]">{booking.address}</span>
                                </div>
                              </div>
                            </div>
                            
                            <div className="flex flex-wrap items-center gap-6">
                              <div className="flex items-center gap-2">
                                <Calendar size={18} className="text-primary" />
                                <span className="font-bold text-secondary text-sm">{booking.date}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Clock size={18} className="text-primary" />
                                <div className="flex flex-col">
                                  <span className="font-bold text-secondary text-sm">{booking.time}</span>
                                  {booking.estimatedArrival && (
                                    <span className="text-[10px] text-primary font-bold">Arrival: {booking.estimatedArrival}</span>
                                  )}
                                </div>
                              </div>
                            </div>

                            <div className="flex flex-col items-end">
                              <span className="text-sm font-bold text-text-muted uppercase tracking-widest leading-none mb-1">Fee</span>
                              <span className="text-xl font-bold font-display text-primary leading-none">₹{booking.amount}</span>
                            </div>
                          </div>
                          
                          <div className="mt-6 pt-6 border-t border-gray-50">
                            <button 
                              onClick={() => acceptJob(booking.id)}
                              className="w-full bg-primary text-white py-3 rounded-xl font-bold shadow-lg shadow-primary/20 hover:scale-[1.01] active:scale-95 transition-all"
                            >
                              Accept Job
                            </button>
                          </div>
                        </div>
                      ))}
                      {bookings.filter(b => b.status === 'pending').length === 0 && (
                        <div className="text-center py-20 bg-soft-bg rounded-[32px] border-2 border-dashed border-gray-200">
                          <Search className="mx-auto text-gray-300 mb-4" size={48} />
                          <p className="text-text-muted font-bold">No jobs available right now. Check back later!</p>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}

                {activeTab === 'history' && (
                  <motion.div
                    key="history"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="p-8 md:p-12"
                  >
                    <div className="flex justify-between items-center mb-8">
                      <h3 className="text-3xl font-display font-bold text-secondary">Work History</h3>
                    </div>

                    <div className="space-y-4">
                      {bookings
                        .filter(b => b.status === 'completed' && b.maidId === user.id)
                        .map((booking) => (
                        <div key={booking.id} className="p-6 rounded-3xl border-2 border-gray-50 flex flex-col md:flex-row md:items-center justify-between gap-6 opacity-80">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center text-green-600 text-xl">
                              <CheckCircle size={24} />
                            </div>
                            <div>
                              <h4 className="font-bold text-secondary">{booking.service}</h4>
                              <p className="text-sm text-text-muted">{booking.date} at {booking.time}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-6">
                            <div className="text-right">
                              <p className="text-xs font-bold text-text-muted uppercase">Paid</p>
                              <p className="font-bold text-secondary">₹{booking.amount}</p>
                            </div>
                            <div className="bg-green-50 text-green-600 px-3 py-1 rounded-lg text-xs font-bold uppercase">
                              Completed
                            </div>
                          </div>
                        </div>
                      ))}
                      {bookings.filter(b => b.status === 'completed' && b.maidId === user.id).length === 0 && (
                        <div className="text-center py-20">
                          <Clock className="mx-auto text-gray-200 mb-4" size={48} />
                          <p className="text-text-muted font-bold">Your work history will appear here.</p>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}

                {activeTab === 'payments' && (
                  <motion.div
                    key="payments"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="p-8 md:p-12 text-center"
                  >
                    <div className="w-20 h-20 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Wallet size={40} />
                    </div>
                    <h3 className="text-3xl font-display font-bold text-secondary mb-2">Earnings Overview</h3>
                    <p className="text-text-muted max-w-sm mx-auto mb-12">Track your daily and weekly earnings with detailed payment breakdowns.</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
                       <div className="bg-soft-bg p-8 rounded-[32px] border border-gray-100">
                          <span className="text-text-muted font-bold text-xs uppercase tracking-widest mb-2 block">Weekly Payout</span>
                          <span className="text-4xl font-display font-bold text-secondary">₹3,450.00</span>
                          <p className="text-purple-600 font-bold text-sm mt-2 flex items-center gap-1">
                            <CheckCircle size={14} /> Available for withdrawal
                          </p>
                          <button className="mt-8 w-full bg-primary text-white py-4 rounded-2xl font-bold shadow-xl">Withdraw to Bank</button>
                       </div>
                       <div className="bg-white p-8 rounded-[32px] border-2 border-soft-bg">
                          <span className="text-text-muted font-bold text-xs uppercase tracking-widest mb-2 block">Next Payout</span>
                          <span className="text-4xl font-display font-bold text-secondary opacity-50">₹1,200.00</span>
                          <p className="text-text-muted font-bold text-sm mt-2">Processing on Friday, Apr 24</p>
                       </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'profile' && (
                  <motion.div
                    key="profile"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="p-8 md:p-12"
                  >
                    <h3 className="text-3xl font-display font-bold text-secondary mb-8">Personal Information</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                       <div className="space-y-4">
                          <label className="text-sm font-bold text-secondary uppercase tracking-wider">Display Name</label>
                          <input 
                            type="text" 
                            value={profileData.name} 
                            onChange={(e) => setProfileData({...profileData, name: e.target.value})}
                            className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none font-medium" 
                          />
                       </div>
                       <div className="space-y-4">
                          <label className="text-sm font-bold text-secondary uppercase tracking-wider">Phone</label>
                          <input 
                            type="text" 
                            value={profileData.phone} 
                            onChange={(e) => setProfileData({...profileData, phone: e.target.value})}
                            className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none font-medium" 
                          />
                       </div>
                       <div className="space-y-4">
                          <label className="text-sm font-bold text-secondary uppercase tracking-wider">Aadhar Number</label>
                          <input 
                            type="text" 
                            value={profileData.aadharNumber} 
                            onChange={(e) => setProfileData({...profileData, aadharNumber: e.target.value})}
                            className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none font-medium" 
                          />
                       </div>
                       <div className="space-y-4">
                          <label className="text-sm font-bold text-secondary uppercase tracking-wider">City</label>
                          <input 
                            type="text" 
                            value={profileData.city} 
                            onChange={(e) => setProfileData({...profileData, city: e.target.value})}
                            className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none font-medium" 
                          />
                       </div>
                       <div className="space-y-4 md:col-span-2">
                          <label className="text-sm font-bold text-secondary uppercase tracking-wider">Current Address</label>
                          <textarea 
                            rows={2} 
                            value={profileData.currentAddress} 
                            onChange={(e) => setProfileData({...profileData, currentAddress: e.target.value})}
                            className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none font-medium resize-none" 
                          />
                       </div>
                       <div className="space-y-4 md:col-span-2">
                          <label className="text-sm font-bold text-secondary uppercase tracking-wider">Family Details</label>
                          <textarea 
                            rows={2} 
                            value={profileData.familyDetails} 
                            onChange={(e) => setProfileData({...profileData, familyDetails: e.target.value})}
                            className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none font-medium resize-none" 
                          />
                       </div>
                    </div>
                    <button 
                      onClick={handleSaveProfile}
                      disabled={isSaving}
                      className="mt-12 bg-primary text-white px-12 py-5 rounded-2xl font-bold shadow-xl hover:scale-105 active:scale-95 transition-all disabled:opacity-50"
                    >
                      {isSaving ? 'Saving Changes...' : 'Save Changes'}
                    </button>
                  </motion.div>
                )}

                {activeTab === 'documents' && (
                  <motion.div
                    key="documents"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="p-8 md:p-12"
                  >
                    <div className="flex items-center gap-4 mb-8">
                      <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center">
                        <Shield size={24} />
                      </div>
                      <div>
                        <h3 className="text-3xl font-display font-bold text-secondary">Verification</h3>
                        <p className="text-text-muted">Manage your documents for background check.</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {[
                        { name: 'Aadhar Card', key: 'Aadhar Card' },
                        { name: 'Pan Card', key: 'Pan Card' },
                        { name: 'Police Verification', key: 'Police Verification' },
                        { name: 'Address Proof', key: 'Address Proof' }
                      ].map((docItem, idx) => {
                        const status = (user.verificationStatus as any)?.[docItem.key] || 'not_uploaded';
                        const isVerified = status === 'verified';
                        const isPending = status === 'pending';
                        
                        return (
                          <div key={idx} className="p-8 rounded-[32px] border-2 border-gray-50 flex items-center justify-between group hover:border-primary/20 transition-all">
                            <div className="flex items-center gap-4">
                              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                                isVerified ? 'bg-orange-50 text-orange-600' : 
                                isPending ? 'bg-purple-50 text-purple-500' : 'bg-orange-50 text-orange-500'
                              }`}>
                                {isVerified ? <CheckCircle size={20} /> : isPending ? <Clock size={20} /> : <XCircle size={20} />}
                              </div>
                              <div>
                                <h4 className="font-bold text-secondary">{docItem.name}</h4>
                                <p className={`text-xs font-bold uppercase tracking-widest ${
                                  isVerified ? 'text-orange-600' : isPending ? 'text-purple-500' : 'text-orange-400'
                                }`}>
                                  {status.replace('_', ' ')}
                                </p>
                              </div>
                            </div>
                            {!isVerified && (
                              <div className="relative">
                                <input 
                                  type="file" 
                                  className="absolute inset-0 opacity-0 cursor-pointer" 
                                  onChange={(e) => handleDocumentUpload(e, docItem.key)}
                                  disabled={uploadingDoc === docItem.key}
                                />
                                <button className="px-6 py-2 bg-primary/10 text-primary rounded-xl font-bold text-sm group-hover:bg-primary group-hover:text-white transition-all">
                                  {uploadingDoc === docItem.key ? 'Uploading...' : isPending ? 'Re-upload' : 'Upload'}
                                </button>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default MaidDashboardPage;
