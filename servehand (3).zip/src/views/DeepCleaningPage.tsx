'use client';

import React from 'react';
import { motion } from 'motion/react';
import Link from 'next/link';
import Footer from '../components/layout/Footer';
import { CheckCircle, Sparkles, Clock, ShieldCheck, ArrowRight } from 'lucide-react';
import { Button } from '../components/ui/button';

const DeepCleaningPage = () => {
  const plans = [
    {
      title: '1 BHK Flat',
      price: '2000',
      duration: '4 Hours',
      features: [
        'Deep cleaning of all rooms',
        'Bathroom sanitization',
        'Kitchen degreasing',
        'Floor scrubbing',
        'Window & fan cleaning'
      ]
    },
    {
      title: '2 BHK Flat',
      price: '3000',
      duration: '5 Hours',
      features: [
        'Deep cleaning of all rooms',
        'Bathroom sanitization',
        'Kitchen degreasing',
        'Floor scrubbing',
        'Window & fan cleaning',
        'Balcony cleaning'
      ]
    }
  ];

  return (
    <div className="pt-24">
      <section className="bg-primary py-24 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-secondary/10 skew-x-12 translate-x-1/4" />
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full text-white font-bold text-sm mb-6">
              <Sparkles size={16} />
              Professional Deep Cleaning
            </div>
            <h1 className="text-5xl md:text-7xl font-display font-bold mb-8">
              Expert <span className="text-accent">Deep Cleaning</span> for Your Home
            </h1>
            <p className="text-xl text-white/80 leading-relaxed">
              Get your home sparkling clean with our professional deep cleaning services. 
              We use industrial-grade equipment and eco-friendly chemicals to ensure a 
              spotless and sanitized living space.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-display font-bold text-secondary mb-4">Choose Your Plan</h2>
            <p className="text-text-muted">Transparent pricing based on your home size. No hidden charges.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {plans.map((plan, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-soft-bg p-10 rounded-[40px] border border-gray-100 shadow-xl hover:shadow-2xl transition-all group"
              >
                <div className="flex justify-between items-start mb-8">
                  <div>
                    <h3 className="text-2xl font-display font-bold text-secondary mb-2">{plan.title}</h3>
                    <div className="flex items-center gap-2 text-primary font-bold">
                      <Clock size={18} />
                      {plan.duration}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-text-muted uppercase tracking-widest">Starting at</p>
                    <p className="text-4xl font-display font-bold text-primary">₹{plan.price}</p>
                  </div>
                </div>

                <ul className="space-y-4 mb-10">
                  {plan.features.map((feature, j) => (
                    <li key={j} className="flex items-center gap-3 text-secondary font-medium">
                      <CheckCircle size={20} className="text-primary" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <Link href="/dashboard/book">
                  <Button className="w-full py-8 rounded-2xl text-lg font-bold shadow-xl shadow-primary/20 group-hover:scale-[1.02] transition-transform">
                    Book Now <ArrowRight className="ml-2" />
                  </Button>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-soft-bg">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <h2 className="text-4xl font-display font-bold text-secondary">Why Our Deep Cleaning?</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {[
                  { icon: <ShieldCheck className="text-primary" />, title: 'Expert Team', desc: 'Trained professionals with specialized equipment.' },
                  { icon: <Sparkles className="text-primary" />, title: 'Eco-Friendly', desc: 'Safe chemicals for your family and pets.' },
                  { icon: <Clock className="text-primary" />, title: 'On-Time', desc: 'We value your schedule and arrive promptly.' },
                  { icon: <ShieldCheck className="text-primary" />, title: 'Satisfaction', desc: '100% satisfaction guarantee or free re-clean.' },
                ].map((item, i) => (
                  <div key={i} className="p-6 bg-white rounded-3xl shadow-md space-y-3">
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary">
                      {item.icon}
                    </div>
                    <h3 className="font-bold text-secondary">{item.title}</h3>
                    <p className="text-sm text-text-muted">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1581578731548-c64695cc6958?auto=format&fit=crop&q=80&w=800&h=1000" 
                alt="Deep Cleaning Process" 
                className="rounded-[40px] shadow-2xl"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default DeepCleaningPage;
