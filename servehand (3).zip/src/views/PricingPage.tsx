'use client';

import React from 'react';
import { motion } from 'motion/react';
import PricingSection from '../components/layout/PricingSection';
import Footer from '../components/layout/Footer';
import { Check, Info } from 'lucide-react';

const PricingPage = () => {
  return (
    <div className="pt-24">
      <section className="bg-soft-bg py-20 text-secondary overflow-hidden relative">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-primary/5 skew-x-12 translate-x-1/4" />
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-6xl font-display font-bold mb-6"
          >
            Simple, Transparent <span className="text-primary">Pricing</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-text-muted max-w-2xl"
          >
            No hidden fees. No surprises. Choose a plan that fits your needs 
            and budget. All plans include verified and trained professionals.
          </motion.p>
        </div>
      </section>

      <PricingSection />

      <section className="py-24 bg-white">
        <div className="max-w-4xl mx-auto px-6">
          <h2 className="text-4xl font-display font-bold text-secondary text-center mb-16">All Plans Include</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              'Background-checked professionals',
              'GPS-tracked real-time arrival',
              'Free replacement if unsatisfied',
              'Dedicated relationship manager',
              'Secure online payments',
              'Flexible rescheduling',
              'Insurance coverage for damages',
              '24/7 customer support',
            ].map((feature, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="flex items-center gap-4 p-4 bg-soft-bg rounded-2xl border border-gray-100"
              >
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center text-primary shrink-0">
                  <Check size={20} />
                </div>
                <span className="font-bold text-secondary">{feature}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-secondary text-white">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full text-primary font-bold mb-8">
            <Info size={18} />
            Need a custom plan?
          </div>
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-8">For Large Families & Businesses</h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-12">
            We offer tailored solutions for large households, corporate offices, 
            and commercial spaces. Contact our sales team for a custom quote.
          </p>
          <button className="bg-primary text-white px-10 py-4 rounded-2xl font-bold text-lg hover:bg-primary/90 transition-all shadow-xl">
            Contact Sales
          </button>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default PricingPage;
