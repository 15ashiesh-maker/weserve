'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import Footer from '../components/layout/Footer';
import { Mail, Phone, MapPin, Send, MessageCircle } from 'lucide-react';
import { doc, setDoc } from 'firebase/firestore';
import { db, handleFirestoreError } from '../lib/firebase';
import { z } from 'zod';

const contactSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Invalid email address'),
  phone: z.string().min(10, 'Phone must be at least 10 digits'),
  subject: z.string(),
  message: z.string().min(10, 'Message must be at least 10 characters')
});

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'General Inquiry',
    message: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [statusText, setStatusText] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setStatusText('');
    setErrors({});
    
    try {
      // Validate with Zod
      const result = contactSchema.safeParse(formData);
      if (!result.success) {
        const fieldErrors: Record<string, string> = {};
        result.error.issues.forEach((err) => {
          if (err.path[0]) {
            fieldErrors[err.path[0] as string] = err.message;
          }
        });
        setErrors(fieldErrors);
        setStatusText('Please fix the errors in the form.');
        setIsLoading(false);
        return;
      }

      const messageId = Math.random().toString(36).substring(2, 15);
      await setDoc(doc(db, 'messages', messageId), {
        ...formData,
        createdAt: new Date().toISOString()
      }).catch(err => handleFirestoreError(err, 'create', `messages/${messageId}`));
      
      setStatusText('Message sent successfully! We will get back to you soon.');
      setFormData({ name: '', email: '', phone: '', subject: 'General Inquiry', message: '' });
    } catch (error: any) {
      console.error(error);
      setStatusText('Failed to send message. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="pt-24">
      <section className="bg-primary py-20 text-white overflow-hidden relative">
        <div className="absolute top-0 left-0 w-1/2 h-full bg-secondary/10 -skew-x-12 -translate-x-1/4" />
        <div className="max-w-7xl mx-auto px-6 relative z-10 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-6xl font-display font-bold mb-6"
          >
            Contact <span className="text-secondary">Us</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-white/80 max-w-2xl mx-auto"
          >
            Have questions? We're here to help. Reach out to us through any 
            of the channels below or fill out the form.
          </motion.p>
        </div>
      </section>

      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Contact Info */}
            <div className="lg:col-span-1 space-y-8">
              <h2 className="text-3xl font-display font-bold text-secondary mb-8">Get in Touch</h2>
              {[
                { icon: <Phone />, title: 'Call Us', desc: '+91 80810 22033', sub: 'Mon-Sat, 9am - 7pm' },
                { icon: <Mail />, title: 'Email Us', desc: 'support@servehand.com', sub: 'Response within 24 hours' },
                { icon: <MapPin />, title: 'Visit Us', desc: 'Galaxy Sapphire, Noida Extension, Noida, Uttar Pradesh', sub: 'Corporate Office' },
                { icon: <MessageCircle />, title: 'WhatsApp', desc: '+91 80810 22033', sub: 'Instant Support' },
              ].map((item, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="flex gap-6 p-6 bg-soft-bg rounded-3xl border border-gray-100 hover:border-primary transition-colors"
                >
                  <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center text-primary shrink-0">
                    {item.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-secondary mb-1">{item.title}</h3>
                    <p className="text-secondary font-medium">{item.desc}</p>
                    <p className="text-sm text-text-muted">{item.sub}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-white p-8 md:p-12 rounded-[40px] shadow-2xl border border-gray-50"
              >
                <h2 className="text-3xl font-display font-bold text-secondary mb-8">Send us a Message</h2>
                
                {statusText && (
                  <div className={`p-4 rounded-xl mb-6 font-bold ${statusText.includes('successfully') ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
                    {statusText}
                  </div>
                )}

                <form className="space-y-6" onSubmit={handleSubmit}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-secondary uppercase tracking-wider">Full Name</label>
                      <input 
                        type="text" 
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        placeholder="John Doe" 
                        className={`w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 outline-none transition-all font-medium ${errors.name ? 'border-red-400 focus:border-red-400' : 'border-transparent focus:border-primary'}`}
                      />
                      {errors.name && <p className="text-xs text-red-500 font-bold">{errors.name}</p>}
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-secondary uppercase tracking-wider">Email Address</label>
                      <input 
                        type="email" 
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        placeholder="john@example.com" 
                        className={`w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 outline-none transition-all font-medium ${errors.email ? 'border-red-400 focus:border-red-400' : 'border-transparent focus:border-primary'}`}
                      />
                      {errors.email && <p className="text-xs text-red-500 font-bold">{errors.email}</p>}
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-secondary uppercase tracking-wider">Phone Number</label>
                      <input 
                        type="tel" 
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData({...formData, phone: e.target.value})}
                        placeholder="+91 80810 22033" 
                        className={`w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 outline-none transition-all font-medium ${errors.phone ? 'border-red-400 focus:border-red-400' : 'border-transparent focus:border-primary'}`}
                      />
                      {errors.phone && <p className="text-xs text-red-500 font-bold">{errors.phone}</p>}
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-secondary uppercase tracking-wider">Subject</label>
                      <select 
                        required
                        value={formData.subject}
                        onChange={(e) => setFormData({...formData, subject: e.target.value})}
                        className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none transition-all font-medium appearance-none"
                      >
                        <option>General Inquiry</option>
                        <option>Service Booking</option>
                        <option>Feedback</option>
                        <option>Complaint</option>
                        <option>Other</option>
                      </select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-secondary uppercase tracking-wider">Message</label>
                    <textarea 
                      rows={6} 
                      required
                      value={formData.message}
                      onChange={(e) => setFormData({...formData, message: e.target.value})}
                      placeholder="How can we help you?" 
                      className={`w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 outline-none transition-all font-medium resize-none ${errors.message ? 'border-red-400 focus:border-red-400' : 'border-transparent focus:border-primary'}`}
                    />
                    {errors.message && <p className="text-xs text-red-500 font-bold">{errors.message}</p>}
                  </div>
                  <button 
                    disabled={isLoading}
                    className="w-full bg-primary text-white py-5 rounded-2xl font-bold text-lg shadow-xl hover:bg-primary/90 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
                  >
                    <Send size={20} />
                    {isLoading ? 'Sending...' : 'Send Message'}
                  </button>
                </form>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default ContactPage;
