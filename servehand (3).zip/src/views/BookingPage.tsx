'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useRouter } from 'next/navigation';
import Footer from '../components/layout/Footer';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  User, 
  ArrowRight, 
  CheckCircle, 
  Sparkles, 
  ShieldCheck, 
  CreditCard,
  Info,
  AlertTriangle,
  Zap,
  Repeat
} from 'lucide-react';
import { useStore } from '../store/useStore';
import { cn } from '../lib/utils';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { doc, setDoc } from 'firebase/firestore';
import { db, handleFirestoreError } from '../lib/firebase';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../components/ui/dialog";
import { Calendar as CalendarUI } from "../components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "../components/ui/popover";
import { format } from "date-fns";

const services = [
  { 
    id: 'maid', 
    name: 'Maid Service', 
    price: 100, 
    icon: '🧹',
    description: 'Expert home cleaning and organization',
    features: ['Sweeping', 'Mopping', 'Dusting']
  },
  { 
    id: 'cook', 
    name: 'Personal Cook', 
    price: 200, 
    icon: '🍳',
    description: 'Fresh home-style meals prepared for you',
    features: ['Meal Prep', 'Dietary focus', 'Clean-up']
  },
  { 
    id: 'elderly', 
    name: 'Elderly Care', 
    price: 200, 
    icon: '👵',
    description: 'Compassionate assistance for seniors',
    features: ['Medication help', 'Mobility', 'Comfort']
  },
  { 
    id: 'babysitter', 
    name: 'Baby Sitting', 
    price: 100, 
    icon: '👶',
    description: 'Safe and engaging care for your children',
    features: ['Active Play', 'Feeding', 'Safety']
  },
  { 
    id: 'petcare', 
    name: 'Pet Care', 
    price: 200, 
    icon: '🐕',
    description: 'Premium walking and grooming',
    features: ['Daily Walk', 'Bath', 'Feeding']
  },
  { 
    id: 'cleaning', 
    name: 'Deep Cleaning', 
    price: 0, 
    icon: '✨',
    description: 'Heavy-duty sanitization and refresh',
    features: ['End-to-end', 'Heavy Stains', 'Sanitization']
  },
];

const daysOfWeek = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

const BookingPage = () => {
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [planType, setPlanType] = useState<'instant' | 'one-time' | 'weekly' | 'monthly'>('one-time');
  const [flatType, setFlatType] = useState<'1bhk' | '2bhk' | null>(null);
  const [selectedDays, setSelectedDays] = useState<string[]>([]);
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [time, setTime] = useState('09:00 AM');
  const [address, setAddress] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [step, setStep] = useState(1);
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [lastBookingId, setLastBookingId] = useState<string | null>(null);

  const user = useStore((state) => state.user);
  const router = useRouter();

  const selectedServiceData = services.find(s => s.id === selectedService);
  
  const calculateTotal = () => {
    if (!selectedServiceData) return 0;
    
    if (selectedService === 'cleaning') {
      if (flatType === '1bhk') return 2000;
      if (flatType === '2bhk') return 3000;
      return 0;
    }

    const basePrice = selectedServiceData.price;
    if (planType === 'weekly') {
      return basePrice * selectedDays.length * 4; // Monthly estimate for weekly days
    }
    if (planType === 'instant') {
      return basePrice + 150; // Extra charge for instant service
    }
    return basePrice;
  };

  const today = new Date().toISOString().split('T')[0];

  const toggleDay = (day: string) => {
    setSelectedDays(prev => 
      prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day]
    );
  };

  const dayMap: { [key: string]: number } = {
    'Sun': 0, 'Mon': 1, 'Tue': 2, 'Wed': 3, 'Thu': 4, 'Fri': 5, 'Sat': 6
  };

  const highlightedDays = selectedDays.map(d => dayMap[d]);

  const modifiers = {
    selectedSchedule: (date: Date) => planType === 'weekly' && highlightedDays.includes(date.getDay())
  };

  const modifiersClassNames = {
    selectedSchedule: "highlighted-day"
  };

  const resetForm = () => {
    setStep(1);
    setSelectedService(null);
    setPlanType('one-time');
    setFlatType(null);
    setSelectedDays([]);
    setDate(undefined);
    setTime('09:00 AM');
    setAddress('');
    setIsSubmitting(false);
    setIsConfirmOpen(false);
    setLastBookingId(null);
  };

  const handleBooking = async () => {
    if (!user) {
      router.push('/login');
      return;
    }

    if (planType === 'monthly') {
      router.push('/contact');
      return;
    }

    if (!selectedService || !date || !time || !address) {
      alert('Please fill all details');
      return;
    }

    if (planType === 'weekly' && selectedDays.length === 0) {
      alert('Please select at least one day for weekly plan');
      return;
    }

    setIsSubmitting(true);
    setIsConfirmOpen(false);
    
    try {
      const generatedId = Math.random().toString(36).substring(2, 11).toUpperCase();
      setLastBookingId(generatedId);
      
      const estimatedArrival = `${time} - ${format(new Date(new Date(`2026-01-01 ${time}`).getTime() + 30 * 60000), 'hh:mm a')}`;
      
      const bookingData = {
        service: `${selectedServiceData?.name}${planType === 'weekly' ? ' (Weekly)' : ''}`,
        date: planType === 'weekly' ? `Starts ${date ? format(date, 'PPP') : ''} (${selectedDays.join(', ')})` : (date ? format(date, 'PPP') : ''),
        time,
        estimatedArrival,
        address,
        amount: calculateTotal() + 49, // including service fee
        status: 'pending',
        userId: user.id,
        createdAt: new Date().toISOString()
      };

      await setDoc(doc(db, 'bookings', generatedId), bookingData)
        .catch(err => handleFirestoreError(err, 'create', `bookings/${generatedId}`, user));

      setIsSubmitting(false);
      setStep(4); // Success step
    } catch (error) {
      console.error(error);
      alert('Failed to book service. Please try again.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="pt-24 bg-soft-bg min-h-screen">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Booking Form */}
          <div className="lg:col-span-2 space-y-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white p-8 md:p-12 rounded-[40px] shadow-2xl border border-gray-50"
            >
              <div className="flex items-center justify-between mb-8">
                <h1 className="text-4xl font-display font-bold text-secondary">Book a <span className="text-primary">Service</span></h1>
                <Badge variant="outline" className="px-4 py-1 rounded-full border-primary/20 text-primary font-bold">
                  Step {step > 3 ? 3 : step} of 3
                </Badge>
              </div>
              
              <AnimatePresence mode="wait">
                {step === 1 && (
                  <motion.div 
                    key="step1"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-8"
                  >
                    <div className="space-y-6">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-primary text-white rounded-full flex items-center justify-center font-bold shadow-lg shadow-primary/20">1</div>
                        <h2 className="text-2xl font-display font-bold text-secondary">Select Service</h2>
                      </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
                          {services.map((service) => (
                            <div 
                              key={service.id}
                              onClick={() => setSelectedService(service.id)}
                              className={`p-6 rounded-3xl border-2 transition-all text-left flex gap-6 group relative overflow-hidden cursor-pointer ${
                                selectedService === service.id 
                                  ? 'border-primary bg-primary/5 ring-4 ring-primary/10 shadow-lg' 
                                  : 'border-soft-bg hover:border-primary/50 hover:bg-primary/5 bg-white'
                              }`}
                            >
                              <div className={`text-5xl transition-transform group-hover:scale-110 shrink-0 flex items-center justify-center bg-soft-bg rounded-2xl w-20 h-20 ${selectedService === service.id ? 'scale-110 bg-primary/20' : ''}`}>
                                {service.icon}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-start mb-1">
                                  <h3 className="font-bold text-secondary text-lg truncate pr-6">{service.name}</h3>
                                  <span className="text-primary font-bold whitespace-nowrap">
                                    {service.price > 0 ? `₹${service.price}/hr` : 'Custom'}
                                  </span>
                                </div>
                                <p className="text-xs text-text-muted mb-3 line-clamp-1">{service.description}</p>
                                <div className="flex items-center justify-between mt-auto">
                                  <div className="flex gap-2 flex-wrap">
                                    {service.features.map(f => (
                                      <span key={f} className="text-[10px] bg-gray-100 text-secondary px-2 py-0.5 rounded-full font-medium italic">
                                        {f}
                                      </span>
                                    ))}
                                  </div>
                                  <Button 
                                    size="sm"
                                    variant={selectedService === service.id ? "default" : "outline"}
                                    className={cn(
                                      "rounded-xl font-bold ml-4 h-8 px-3 text-xs",
                                      selectedService === service.id ? "bg-primary text-white" : ""
                                    )}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setSelectedService(service.id);
                                    }}
                                  >
                                    {selectedService === service.id ? 'Selected' : 'Select Service'}
                                  </Button>
                                </div>
                              </div>
                              {selectedService === service.id && (
                                <div className="absolute top-2 right-2 text-primary animate-in zoom-in duration-300">
                                  <CheckCircle size={20} fill="currentColor" className="text-white" />
                                </div>
                              )}
                            </div>
                          ))}
                        </div>

                      {selectedService && (
                        <div className="space-y-6 pt-6 border-t border-gray-100">
                          {selectedService === 'cleaning' && (
                            <div className="space-y-4 animate-in fade-in slide-in-from-top-2">
                              <h3 className="text-xl font-bold text-secondary">Select Flat Type</h3>
                              <div className="grid grid-cols-2 gap-4">
                                <button 
                                  onClick={() => setFlatType('1bhk')}
                                  className={`p-4 rounded-2xl border-2 transition-all text-left ${
                                    flatType === '1bhk' ? 'border-primary bg-primary/5' : 'border-soft-bg hover:border-primary/30'
                                  }`}
                                >
                                  <p className="font-bold text-secondary">1 BHK Flat</p>
                                  <p className="text-sm font-bold text-primary">₹2000 (4 Hours)</p>
                                </button>
                                <button 
                                  onClick={() => setFlatType('2bhk')}
                                  className={`p-4 rounded-2xl border-2 transition-all text-left ${
                                    flatType === '2bhk' ? 'border-primary bg-primary/5' : 'border-soft-bg hover:border-primary/30'
                                  }`}
                                >
                                  <p className="font-bold text-secondary">2 BHK Flat</p>
                                  <p className="text-sm font-bold text-primary">₹3000 (5 Hours)</p>
                                </button>
                              </div>
                            </div>
                          )}

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
                            {/* Group 1: On-Demand */}
                            <div className="space-y-4 p-6 rounded-[32px] bg-orange-50/50 border border-orange-100 flex flex-col">
                              <div className="flex items-center gap-2 text-orange-700">
                                <Zap size={18} className="fill-orange-500 text-orange-500" />
                                <h3 className="font-bold uppercase tracking-wider text-xs">Flexible Options</h3>
                              </div>
                              <div className="space-y-3 flex-1">
                                <button 
                                  onClick={() => setPlanType('instant')}
                                  className={`w-full p-5 rounded-2xl border-2 transition-all text-left relative group ${
                                    planType === 'instant' ? 'border-orange-500 bg-white ring-4 ring-orange-500/10 shadow-md' : 'border-white bg-white/50 hover:border-orange-200 hover:bg-white'
                                  }`}
                                >
                                  <div className="flex justify-between items-start mb-2">
                                    <p className="font-bold text-secondary">Instant Service</p>
                                    {planType === 'instant' && <CheckCircle size={16} className="text-orange-500" />}
                                  </div>
                                  <p className="text-[11px] text-text-muted leading-relaxed">Helper arrives within 60 mins for urgent needs. Premium surcharge applies.</p>
                                </button>
                                <button 
                                  onClick={() => setPlanType('one-time')}
                                  className={`w-full p-5 rounded-2xl border-2 transition-all text-left relative group ${
                                    planType === 'one-time' ? 'border-orange-500 bg-white ring-4 ring-orange-500/10 shadow-md' : 'border-white bg-white/50 hover:border-orange-200 hover:bg-white'
                                  }`}
                                >
                                  <div className="flex justify-between items-start mb-2">
                                    <p className="font-bold text-secondary">One-time visit</p>
                                    {planType === 'one-time' && <CheckCircle size={16} className="text-orange-500" />}
                                  </div>
                                  <p className="text-[11px] text-text-muted leading-relaxed">Schedule a single session at your convenience. Perfect for ad-hoc needs.</p>
                                </button>
                              </div>
                              <Badge className="bg-orange-100 text-orange-700 border-none mx-auto py-1 px-4 rounded-full text-[10px] font-black tracking-widest">NO COMMITMENT</Badge>
                            </div>

                            {/* Group 2: Subscription */}
                            <div className="space-y-4 p-6 rounded-[32px] bg-primary/5 border border-primary/10 flex flex-col">
                              <div className="flex items-center gap-2 text-primary">
                                <Repeat size={18} className="text-primary" />
                                <h3 className="font-bold uppercase tracking-wider text-xs">Recurring Help</h3>
                              </div>
                              <div className="space-y-3 flex-1">
                                <button 
                                  onClick={() => setPlanType('weekly')}
                                  className={`w-full p-5 rounded-2xl border-2 transition-all text-left relative group ${
                                    planType === 'weekly' ? 'border-primary bg-white ring-4 ring-primary/10 shadow-md' : 'border-white bg-white/50 hover:border-primary/20 hover:bg-white'
                                  }`}
                                >
                                  <div className="flex justify-between items-start mb-2">
                                    <p className="font-bold text-secondary">Weekly Plan</p>
                                    {planType === 'weekly' && <CheckCircle size={16} className="text-primary" />}
                                  </div>
                                  <p className="text-[11px] text-text-muted leading-relaxed">Regular help on specific days each week. Priority matching & fixed pricing.</p>
                                </button>
                                <button 
                                  onClick={() => setPlanType('monthly')}
                                  className={`w-full p-5 rounded-2xl border-2 transition-all text-left relative group ${
                                    planType === 'monthly' ? 'border-primary bg-white ring-4 ring-primary/10 shadow-md' : 'border-white bg-white/50 hover:border-primary/20 hover:bg-white'
                                  }`}
                                >
                                  <div className="flex justify-between items-start mb-2">
                                    <p className="font-bold text-secondary">Custom Monthly</p>
                                    {planType === 'monthly' && <CheckCircle size={16} className="text-primary" />}
                                  </div>
                                  <p className="text-[11px] text-text-muted leading-relaxed">Full-time support tailored for long-term consistency. Contact for personalized quote.</p>
                                </button>
                              </div>
                              <Badge className="bg-primary/10 text-primary border-none mx-auto py-1 px-4 rounded-full text-[10px] font-black tracking-widest">BEST VALUE</Badge>
                            </div>
                          </div>

                          {planType === 'weekly' && (
                            <div className="space-y-4 animate-in fade-in slide-in-from-top-2">
                              <p className="text-sm font-bold text-secondary uppercase tracking-wider">Select Recurring Days</p>
                              <div className="flex flex-wrap gap-2">
                                {daysOfWeek.map(day => (
                                  <button
                                    key={day}
                                    onClick={() => toggleDay(day)}
                                    className={`px-4 py-2 rounded-xl font-bold transition-all ${
                                      selectedDays.includes(day) ? 'bg-primary text-white' : 'bg-soft-bg text-secondary hover:bg-primary/10'
                                    }`}
                                  >
                                    {day}
                                  </button>
                                ))}
                              </div>
                              <p className="text-xs text-text-muted italic">
                                * Weekly plans are billed monthly based on selected days.
                              </p>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                    <Button 
                      disabled={!selectedService || (selectedService === 'cleaning' && !flatType)}
                      onClick={() => {
                        if (planType === 'monthly') {
                          router.push('/contact');
                        } else {
                          setStep(2);
                        }
                      }}
                      className="w-full py-8 rounded-3xl text-lg font-bold shadow-xl shadow-primary/20"
                    >
                      {planType === 'monthly' ? 'Contact Us' : 'Next Step'} <ArrowRight className="ml-2" />
                    </Button>
                  </motion.div>
                )}

                {step === 2 && (
                  <motion.div 
                    key="step2"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-8"
                  >
                    <div className="space-y-6">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-primary text-white rounded-full flex items-center justify-center font-bold shadow-lg shadow-primary/20">2</div>
                        <h2 className="text-2xl font-display font-bold text-secondary">Date & Time</h2>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <label className="text-sm font-bold text-secondary uppercase tracking-wider">Select Date</label>
                          <Popover>
                            <PopoverTrigger>
                              <Button
                                variant={"outline"}
                                className={cn(
                                  "w-full pl-6 pr-6 py-8 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none transition-all font-medium justify-start text-left",
                                  !date && "text-muted-foreground"
                                )}
                              >
                                <Calendar className="mr-4 text-gray-400" size={20} />
                                {date ? format(date, "PPP") : <span>Pick a date</span>}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0 rounded-[32px] overflow-hidden shadow-2xl border-none">
                              <CalendarUI
                                mode="single"
                                selected={date}
                                onSelect={setDate}
                                disabled={(date) => date < new Date(new Date().setHours(0,0,0,0))}
                                modifiers={modifiers}
                                modifiersClassNames={modifiersClassNames}
                                className="bg-white"
                              />
                              {planType === 'weekly' && selectedDays.length > 0 && (
                                <div className="p-4 bg-primary/5 border-t border-primary/10">
                                  <p className="text-[10px] font-bold text-primary uppercase tracking-widest flex items-center gap-2">
                                    <Sparkles size={12} /> Highlighted days matching your schedule
                                  </p>
                                </div>
                              )}
                            </PopoverContent>
                          </Popover>
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-bold text-secondary uppercase tracking-wider">Select Time</label>
                          <div className="relative">
                            <Clock className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                            <select 
                              value={time}
                              onChange={(e) => setTime(e.target.value)}
                              className="w-full pl-14 pr-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none transition-all font-medium appearance-none"
                            >
                              <option>09:00 AM</option>
                              <option>11:00 AM</option>
                              <option>02:00 PM</option>
                              <option>04:00 PM</option>
                              <option>06:00 PM</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <Button variant="outline" onClick={() => setStep(1)} className="flex-1 py-8 rounded-3xl font-bold">Back</Button>
                      <Button 
                        disabled={!date || !time}
                        onClick={() => setStep(3)}
                        className="flex-[2] py-8 rounded-3xl text-lg font-bold shadow-xl shadow-primary/20"
                      >
                        Next Step <ArrowRight className="ml-2" />
                      </Button>
                    </div>
                  </motion.div>
                )}

                {step === 3 && (
                  <motion.div 
                    key="step3"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-8"
                  >
                    <div className="space-y-6">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-primary text-white rounded-full flex items-center justify-center font-bold shadow-lg shadow-primary/20">3</div>
                        <h2 className="text-2xl font-display font-bold text-secondary">Service Location</h2>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-bold text-secondary uppercase tracking-wider">Full Address</label>
                        <div className="relative">
                          <MapPin className="absolute left-5 top-4 text-gray-400" size={20} />
                          <textarea 
                            rows={4} 
                            value={address}
                            onChange={(e) => setAddress(e.target.value)}
                            placeholder="Enter your complete address, house no, landmark..." 
                            className="w-full pl-14 pr-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none transition-all font-medium resize-none" 
                          />
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <Button variant="outline" onClick={() => setStep(2)} className="flex-1 py-8 rounded-3xl font-bold">Back</Button>
                      <Button 
                        disabled={!address || isSubmitting}
                        onClick={() => setIsConfirmOpen(true)}
                        className="flex-[2] py-8 rounded-3xl text-lg font-bold shadow-xl shadow-primary/20 bg-primary hover:bg-primary/90"
                      >
                        {isSubmitting ? 'Processing...' : 'Review Booking'}
                      </Button>
                    </div>
                  </motion.div>
                )}

                {step === 4 && (
                  <motion.div 
                    key="success"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-12 space-y-6"
                  >
                    <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                      <CheckCircle size={48} />
                    </div>
                    <h2 className="text-4xl font-display font-bold text-secondary">Booking Confirmed!</h2>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                      <div className="bg-soft-bg p-4 rounded-2xl inline-block">
                        <p className="text-sm font-bold text-text-muted uppercase tracking-widest mb-1">Booking ID</p>
                        <p className="text-xl font-mono font-bold text-secondary">{lastBookingId}</p>
                      </div>
                      <div className="bg-primary/5 p-4 rounded-2xl inline-block border border-primary/10">
                        <p className="text-sm font-bold text-primary uppercase tracking-widest mb-1">Arrival Window</p>
                        <p className="text-xl font-bold text-secondary">{time} - {format(new Date(new Date(`2026-01-01 ${time}`).getTime() + 30 * 60000), 'hh:mm a')}</p>
                      </div>
                    </div>
                    <p className="text-xl text-text-muted max-w-md mx-auto">
                      Your service has been scheduled successfully. You can track the status in your dashboard.
                    </p>
                    <div className="pt-8 flex flex-col sm:flex-row gap-4 justify-center">
                      <Button onClick={() => router.push('/dashboard')} className="py-6 px-8 rounded-2xl font-bold text-lg">
                        Go to Dashboard
                      </Button>
                      <Button variant="outline" onClick={resetForm} className="py-6 px-8 rounded-2xl font-bold text-lg">
                        Book Another Service
                      </Button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </div>

          {/* Summary Sidebar */}
          <div className="lg:col-span-1">
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-secondary text-white p-8 rounded-[40px] shadow-2xl sticky top-32"
            >
              <h2 className="text-2xl font-display font-bold mb-8 flex items-center gap-2">
                <Sparkles className="text-primary" size={24} />
                Booking Summary
              </h2>
              <div className="space-y-6 mb-8">
                <AnimatePresence mode="popLayout">
                  {selectedServiceData && (
                    <motion.div 
                      key="service-details"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="space-y-6 pt-6 border-t border-white/10"
                    >
                      <div className="flex justify-between items-center text-gray-400">
                        <span>Service</span>
                        <span className="text-white font-bold inline-flex items-center gap-2">
                          {selectedServiceData.icon} {selectedServiceData.name}
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-gray-400">
                        <span>Plan</span>
                        <span className="text-white font-bold capitalize">{planType.replace('-', ' ')}</span>
                      </div>
                      {selectedService === 'cleaning' && flatType && (
                        <div className="flex justify-between items-center text-gray-400">
                          <span>Flat Type</span>
                          <span className="text-white font-bold uppercase">{flatType}</span>
                        </div>
                      )}
                      {planType === 'weekly' && selectedDays.length > 0 && (
                        <div className="flex justify-between items-start text-gray-400">
                          <span>Days</span>
                          <span className="text-white font-bold text-right">{selectedDays.join(', ')}</span>
                        </div>
                      )}
                      <div className="flex justify-between items-center text-gray-400">
                        <span>{planType === 'weekly' ? 'Start Date' : 'Date'}</span>
                        <span className="text-white font-bold">{date ? format(date, 'PPP') : 'Not Selected'}</span>
                      </div>
                      <div className="flex justify-between items-center text-gray-400">
                        <span>Time</span>
                        <span className="text-white font-bold">{time}</span>
                      </div>
                      <div className="flex justify-between items-center text-gray-400">
                        <span>Arrival Window</span>
                        <span className="text-primary font-bold">{time} - {format(new Date(new Date(`2026-01-01 ${time}`).getTime() + 30 * 60000), 'hh:mm a')}</span>
                      </div>
                      <div className="flex justify-between items-start text-gray-400">
                        <span>Address</span>
                        <span className="text-white font-bold text-right line-clamp-2 max-w-[150px]">{address || 'Not Provided'}</span>
                      </div>
                      
                      <hr className="border-white/10" />
                      
                      <div className="space-y-2">
                        <div className="flex justify-between items-center text-gray-400 text-sm">
                          <span>Base Price</span>
                          <span>
                            {selectedService === 'cleaning' 
                              ? `₹${calculateTotal()}` 
                              : `₹${selectedServiceData?.price || 0}${planType === 'weekly' ? ' (per day)' : ''}`
                            }
                          </span>
                        </div>
                        <div className="flex justify-between items-center text-gray-400 text-sm">
                          <span>Service Fee</span>
                          <span>₹49</span>
                        </div>
                        {planType === 'instant' && (
                          <div className="flex justify-between items-center text-gray-400 text-sm">
                            <span>Instant Booking Fee</span>
                            <span>₹150</span>
                          </div>
                        )}
                        <div className="flex justify-between items-center text-xl font-bold pt-2">
                          <span>Total Amount</span>
                          <span className="text-primary">
                            ₹{calculateTotal() + (selectedServiceData ? 49 : 0)}
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  )}
                  {!selectedServiceData && (
                    <motion.div 
                      key="no-service"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="py-12 text-center text-gray-400 space-y-4"
                    >
                      <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4 border border-white/10">
                        <Calendar size={32} className="opacity-20" />
                      </div>
                      <p className="text-sm font-medium">Select a service to see the pricing summary</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
              
              <div className="p-6 bg-white/5 rounded-3xl border border-white/10 space-y-4">
                <div className="flex gap-3">
                  <ShieldCheck size={20} className="text-primary shrink-0" />
                  <p className="text-sm text-gray-300">Verified professionals only</p>
                </div>
                <div className="flex gap-3">
                  <CreditCard size={20} className="text-primary shrink-0" />
                  <p className="text-sm text-gray-300">Secure encrypted payments</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
      
      {/* Confirmation Dialog */}
      <Dialog open={isConfirmOpen} onOpenChange={setIsConfirmOpen}>
        <DialogContent className="max-w-md rounded-[32px] p-0 overflow-hidden border-none shadow-2xl">
          <div className="bg-primary p-8 text-white">
            <DialogHeader>
              <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center mb-4">
                <Info size={24} />
              </div>
              <DialogTitle className="text-2xl font-display font-bold">Verify Booking Details</DialogTitle>
              <DialogDescription className="text-white/80">
                Please review your service details before we proceed with the payment and scheduling.
              </DialogDescription>
            </DialogHeader>
          </div>
          
          <div className="p-8 space-y-6 bg-white">
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-soft-bg rounded-xl flex items-center justify-center text-secondary shrink-0">
                  <Sparkles size={20} />
                </div>
                <div className="flex-1">
                  <p className="text-xs font-bold text-text-muted uppercase tracking-wider">Selected Service</p>
                  <p className="font-bold text-secondary">
                    {selectedServiceData?.name}
                    {selectedService === 'cleaning' && flatType && ` (${flatType.toUpperCase()})`}
                    {planType !== 'one-time' && planType !== 'instant' && ` - ${planType.charAt(0).toUpperCase() + planType.slice(1)} Plan`}
                    {planType === 'instant' && ` (Instant Arrival)`}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-soft-bg rounded-xl flex items-center justify-center text-secondary shrink-0">
                    <Calendar size={20} />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-text-muted uppercase tracking-wider">Date</p>
                    <p className="font-bold text-secondary">{date ? format(date, 'PP') : ''}</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-soft-bg rounded-xl flex items-center justify-center text-secondary shrink-0">
                    <Clock size={20} />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-text-muted uppercase tracking-wider">Time</p>
                    <p className="font-bold text-secondary">{time}</p>
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-soft-bg rounded-xl flex items-center justify-center text-secondary shrink-0">
                  <MapPin size={20} />
                </div>
                <div className="flex-1">
                  <p className="text-xs font-bold text-text-muted uppercase tracking-wider">Address</p>
                  <p className="font-bold text-secondary line-clamp-2">{address}</p>
                </div>
              </div>
            </div>

            <div className="p-4 bg-orange-50 border border-orange-100 rounded-2xl flex gap-3 text-orange-800">
              <AlertTriangle className="shrink-0" size={20} />
              <p className="text-xs leading-relaxed font-medium">
                By clicking confirm, you agree to our service terms. Our professional will arrive at the scheduled time.
              </p>
            </div>

            <div className="flex justify-between items-center p-4 bg-soft-bg rounded-2xl border-2 border-primary/10">
              <div className="flex flex-col">
                <span className="font-bold text-secondary">Total Amount</span>
                <span className="text-[10px] text-text-muted font-bold uppercase">Incl. Service Fees</span>
              </div>
              <span className="text-3xl font-display font-bold text-primary">₹{calculateTotal() + (selectedServiceData ? 49 : 0)}</span>
            </div>
          </div>

          <DialogFooter className="p-6 bg-gray-50 border-t border-gray-100 flex gap-3">
            <Button variant="outline" onClick={() => setIsConfirmOpen(false)} className="flex-1 rounded-xl font-bold h-12">
              Edit Details
            </Button>
            <Button onClick={handleBooking} className="flex-1 rounded-xl font-bold h-12 shadow-lg shadow-primary/20">
              Confirm & Book
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
};

export default BookingPage;
