'use client';

import React from 'react';
import { motion } from 'motion/react';
import WhyUs from '../components/layout/WhyUs';
import Testimonials from '../components/layout/Testimonials';
import Footer from '../components/layout/Footer';
import { ShieldCheck, Zap, UserCheck, Headphones, RefreshCw, Lock } from 'lucide-react';

const WhyUsPage = () => {
  return (
    <div className="pt-24">
      <section className="bg-secondary py-20 text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-primary/10 skew-x-12 translate-x-1/4" />
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-6xl font-display font-bold mb-6"
          >
            Why Choose <span className="text-primary">ServeHand</span>?
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-gray-300 max-w-2xl"
          >
            We are more than just a service provider. We are your partner in 
            creating a better, more comfortable home life.
          </motion.p>
        </div>
      </section>

      <WhyUs />

      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative"
            >
              <img 
                src="https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&q=80&w=800&h=1000" 
                alt="Safety and Verification" 
                className="rounded-[40px] shadow-2xl"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -top-10 -right-10 bg-primary p-8 rounded-3xl shadow-2xl text-white max-w-xs">
                <p className="text-white font-bold text-4xl mb-2">100%</p>
                <p className="text-white/80 font-medium">Background-checked professionals</p>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <h2 className="text-4xl font-display font-bold text-secondary">Our Commitment to Safety</h2>
              <p className="text-xl text-text-muted leading-relaxed">
                Your safety is our top priority. We understand that inviting someone 
                into your home requires trust. That's why we have built a multi-layered 
                verification process that is the most rigorous in the industry.
              </p>
              <div className="space-y-6">
                {[
                  { icon: <ShieldCheck className="text-primary" />, title: 'Identity Verification', desc: 'We verify Aadhar, PAN, and address proof for every helper.' },
                  { icon: <UserCheck className="text-primary" />, title: 'Criminal Record Check', desc: 'We conduct a thorough criminal record check through third-party agencies.' },
                  { icon: <Headphones className="text-primary" />, title: 'Reference Checks', desc: 'We call previous employers to verify work history and behavior.' },
                ].map((item, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="w-12 h-12 bg-soft-bg rounded-xl flex items-center justify-center shrink-0">
                      {item.icon}
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-secondary mb-1">{item.title}</h3>
                      <p className="text-text-muted">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <Testimonials />

      <Footer />
    </div>
  );
};

export default WhyUsPage;
