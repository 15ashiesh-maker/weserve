'use client';

import React from 'react';
import { motion } from 'motion/react';
import HowItWorks from '../components/layout/HowItWorks';
import Footer from '../components/layout/Footer';
import { Search, UserCheck, Calendar, Zap } from 'lucide-react';

const HowItWorksPage = () => {
  return (
    <div className="pt-24">
      <section className="bg-primary py-20 text-white overflow-hidden relative">
        <div className="absolute top-0 left-0 w-1/2 h-full bg-secondary/10 -skew-x-12 -translate-x-1/4" />
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-6xl font-display font-bold mb-6"
          >
            How It <span className="text-secondary">Works</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-white/80 max-w-2xl"
          >
            Booking a professional helper has never been easier. 
            Follow our simple process and get the help you need in minutes.
          </motion.p>
        </div>
      </section>

      <HowItWorks />

      <section className="py-24 bg-soft-bg">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <h2 className="text-4xl font-display font-bold text-secondary">Why Our Process is Better</h2>
              <div className="space-y-6">
                {[
                  { icon: <Search className="text-primary" />, title: 'Advanced Matching', desc: 'Our AI-powered matching system finds the best helper for your specific needs.' },
                  { icon: <UserCheck className="text-primary" />, title: 'Rigorous Verification', desc: 'Every helper undergoes a 5-step verification process before joining our platform.' },
                  { icon: <Calendar className="text-primary" />, title: 'Flexible Scheduling', desc: 'Book for a day, a week, or a month. You have complete control over the schedule.' },
                  { icon: <Zap className="text-primary" />, title: 'Instant Confirmation', desc: 'No more waiting for calls. Get instant confirmation and helper details on your app.' },
                ].map((item, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="w-12 h-12 bg-white rounded-xl shadow-md flex items-center justify-center shrink-0">
                      {item.icon}
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-secondary mb-1">{item.title}</h3>
                      <p className="text-text-muted">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative"
            >
              <img 
                src="https://images.unsplash.com/photo-1581578731548-c64695cc6958?auto=format&fit=crop&q=80&w=800&h=1000" 
                alt="Professional Cleaning Process" 
                className="rounded-[40px] shadow-2xl"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-10 -left-10 bg-white p-8 rounded-3xl shadow-2xl border border-gray-100 max-w-xs">
                <p className="text-primary font-bold text-4xl mb-2">2 min</p>
                <p className="text-secondary font-medium">Average booking time on ServeHand</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default HowItWorksPage;
