'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Chrome, Mail, Lock } from 'lucide-react';
import { auth, db } from '../lib/firebase';
import { signInWithPopup, GoogleAuthProvider, signInWithEmailAndPassword } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';

const LoginPage = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [errorText, setErrorText] = useState('');
  const [showEmailLogin, setShowEmailLogin] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const router = useRouter();

  const handleAuthSuccess = async (uid: string) => {
    const userRef = doc(db, 'users', uid);
    const docSnap = await getDoc(userRef);
    
    if (docSnap.exists()) {
      const userData = docSnap.data();
      if (userData.role === 'maid') {
        if (userData.onboardingCompleted) {
          router.push('/maid-dashboard');
        } else {
          router.push('/onboarding');
        }
      } else {
        router.push('/dashboard');
      }
    } else {
      router.push('/signup');
    }
  };

  const handleGoogleLogin = async () => {
    setIsLoading(true);
    setErrorText('');
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      await handleAuthSuccess(result.user.uid);
    } catch (error: any) {
      console.error(error);
      setErrorText(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorText('');
    try {
      const result = await signInWithEmailAndPassword(auth, email, password);
      await handleAuthSuccess(result.user.uid);
    } catch (error: any) {
      console.error(error);
      setErrorText('Invalid email or password.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-soft-bg px-6 py-24 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(#1E1B4B_1px,transparent_1px)] [background-size:40px_40px]" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="bg-white p-10 md:p-12 rounded-[40px] shadow-2xl border border-gray-50">
          <div className="text-center mb-8">
            <Link href="/" className="inline-flex items-center gap-2 mb-6 group">
              <div className="w-12 h-12 bg-primary rounded-2xl flex items-center justify-center text-white font-bold text-2xl shadow-lg group-hover:scale-110 transition-transform">
                SH
              </div>
              <span className="font-display text-3xl font-bold tracking-tight text-secondary">
                Serve<span className="text-primary">Hand</span>
              </span>
            </Link>
            <h1 className="text-3xl font-display font-bold text-secondary mb-2">Welcome Back!</h1>
            <p className="text-text-muted">Log in to manage your bookings and profile.</p>
          </div>

          {errorText && (
            <div className="bg-red-50 text-red-600 p-3 rounded-lg mb-6 text-sm text-center font-medium">
              {errorText}
            </div>
          )}

          <AnimatePresence mode="wait">
            {!showEmailLogin ? (
              <motion.div 
                key="google"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="space-y-4"
              >
                <button 
                  onClick={handleGoogleLogin}
                  disabled={isLoading}
                  className="flex items-center justify-center gap-3 py-4 px-8 bg-white rounded-2xl border-2 border-gray-100 hover:border-primary hover:bg-gray-50 transition-all font-bold text-secondary w-full"
                >
                  <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-6 h-6" />
                  {isLoading ? 'Connecting...' : 'Continue with Google'}
                </button>
                <button 
                  onClick={() => setShowEmailLogin(true)}
                  className="w-full py-4 text-primary font-bold hover:underline text-sm"
                >
                  Login with Email instead
                </button>
              </motion.div>
            ) : (
              <motion.form 
                key="email"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                onSubmit={handleEmailLogin}
                className="space-y-4"
              >
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-secondary uppercase tracking-wider ml-1">Email</label>
                  <div className="relative">
                    <Mail className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                    <input 
                      type="email" 
                      placeholder="email@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="w-full pl-12 pr-6 py-3.5 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none transition-all font-medium"
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-secondary uppercase tracking-wider ml-1">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                    <input 
                      type="password" 
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="w-full pl-12 pr-6 py-3.5 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none transition-all font-medium"
                    />
                  </div>
                </div>
                <button 
                  disabled={isLoading}
                  className="w-full bg-secondary text-white py-4 rounded-2xl font-bold text-lg shadow-xl hover:bg-secondary/90 transition-all disabled:opacity-50"
                >
                  {isLoading ? 'Logging in...' : 'Login'}
                </button>
                <button 
                  type="button"
                  onClick={() => setShowEmailLogin(false)}
                  className="w-full py-2 text-text-muted font-bold hover:text-secondary text-sm"
                >
                  Go Back
                </button>
              </motion.form>
            )}
          </AnimatePresence>

          <div className="text-center mt-6">
            <Link href="/forgot-password" className="text-sm font-bold text-primary hover:underline">
              Forgot Password?
            </Link>
          </div>

          <p className="text-center mt-10 text-text-muted font-medium">
            Don't have an account? <Link href="/signup" className="text-primary font-bold hover:underline">Sign Up</Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
};

export default LoginPage;
