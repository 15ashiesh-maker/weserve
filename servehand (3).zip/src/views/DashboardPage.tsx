'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  User, 
  Settings, 
  LogOut, 
  Plus, 
  CheckCircle, 
  Clock as ClockIcon, 
  AlertCircle,
  ChevronRight,
  LayoutDashboard,
  Bell,
  Lock,
  Mail,
  Star,
  Shield,
  CreditCard
} from 'lucide-react';
import { useStore, Booking } from '../store/useStore';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';

import { collection, query, where, onSnapshot, orderBy, doc, updateDoc, addDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { signOut } from 'firebase/auth';
import { db, auth, handleFirestoreError } from '../lib/firebase';

const ReviewModal = ({ booking, onClose }: { booking: Booking; onClose: () => void }) => {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { user } = useStore();

  const handleSubmit = async () => {
    if (!user || !booking.maidId) return;
    setIsSubmitting(true);
    try {
      // 1. Create Review
      const reviewData = {
        bookingId: booking.id,
        customerId: user.id,
        customerName: user.name,
        maidId: booking.maidId,
        rating,
        comment,
        createdAt: new Date().toISOString(),
      };
      await addDoc(collection(db, 'reviews'), reviewData);

      // 2. Update Maid Stats
      const maidRef = doc(db, 'users', booking.maidId);
      const maidDoc = await getDoc(maidRef);
      
      if (maidDoc.exists()) {
        const maidData = maidDoc.data();
        const oldCount = maidData.reviewCount || 0;
        const oldRating = maidData.averageRating || 0;
        
        const newCount = oldCount + 1;
        const newRating = ((oldRating * oldCount) + rating) / newCount;
        
        await updateDoc(maidRef, {
          averageRating: Number(newRating.toFixed(1)),
          reviewCount: newCount
        });
      }

      // 3. Mark booking as reviewed (optional, let's just use it to hide button)
      await updateDoc(doc(db, 'bookings', booking.id), {
        isReviewed: true
      });

      alert('Thank you for your review!');
      onClose();
    } catch (error) {
      console.error(error);
      alert('Failed to submit review.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-white rounded-[40px] w-full max-w-lg overflow-hidden shadow-2xl"
      >
        <div className="bg-primary p-8 text-white relative">
          <h2 className="text-2xl font-display font-bold">Rate Your Service</h2>
          <p className="text-white/80">How was your experience with {booking.service}?</p>
          <button onClick={onClose} className="absolute top-8 right-8 text-white/60 hover:text-white">
            <Plus className="rotate-45" size={24} />
          </button>
        </div>
        <div className="p-8 space-y-8">
          <div className="flex flex-col items-center gap-4">
            <p className="text-sm font-bold text-secondary uppercase tracking-widest">Select Rating</p>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button 
                   key={star} 
                  onClick={() => setRating(star)}
                  className={`transition-all ${rating >= star ? 'text-yellow-400 scale-110' : 'text-gray-200 hover:text-gray-300'}`}
                >
                  <Star size={40} fill={rating >= star ? "currentColor" : "none"} strokeWidth={2.5} />
                </button>
              ))}
            </div>
            <p className="text-primary font-black text-xl">
              {rating === 5 ? 'Excellent! 🌟' : 
               rating === 4 ? 'Very Good! 👍' : 
               rating === 3 ? 'Good! 🙂' : 
               rating === 2 ? 'Fair! 😐' : 'Poor! 😞'}
            </p>
          </div>

          <div className="space-y-4">
            <label className="text-sm font-bold text-secondary uppercase tracking-wider block">Your Feedback</label>
            <textarea 
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Tell us what you liked or how we can improve..."
              className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none transition-all font-medium min-h-[120px] resize-none"
            />
          </div>

          <div className="flex gap-4 pt-4">
            <Button variant="outline" onClick={onClose} className="flex-1 h-14 rounded-2xl font-bold">Cancel</Button>
            <Button 
               onClick={handleSubmit} 
              disabled={isSubmitting}
              className="flex-1 h-14 rounded-2xl font-bold shadow-lg shadow-primary/20"
            >
              {isSubmitting ? 'Submitting...' : 'Submit Review'}
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

const DashboardPage = () => {
  const { user, setUser } = useStore();
  const [bookings, setBookings] = useState<(Booking & { isReviewed?: boolean })[]>([]);
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<'dashboard' | 'profile' | 'settings'>('dashboard');
  const [isSaving, setIsSaving] = useState(false);
  const [selectedBookingForReview, setSelectedBookingForReview] = useState<Booking | null>(null);

  // Local state for profile fields
  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    phone: user?.phone || '',
    city: user?.city || ''
  });

  // Local state for notification preferences
  const [pushEnabled, setPushEnabled] = useState(user?.notificationPreferences?.pushNotifications ?? true);
  const [emailEnabled, setEmailEnabled] = useState(user?.notificationPreferences?.emailAlerts ?? true);

  useEffect(() => {
    if (user?.notificationPreferences) {
      setPushEnabled(user.notificationPreferences.pushNotifications);
      setEmailEnabled(user.notificationPreferences.emailAlerts);
    }
  }, [user?.notificationPreferences]);

  const handleUpdateNotifications = async () => {
    if (!user) return;
    setIsSaving(true);
    try {
      const userRef = doc(db, 'users', user.id);
      const newPrefs = {
        pushNotifications: pushEnabled,
        emailAlerts: emailEnabled
      };
      
      await updateDoc(userRef, {
        notificationPreferences: newPrefs
      }).catch(err => handleFirestoreError(err, 'update', `users/${user.id}`, auth.currentUser));
      
      setUser({
        ...user,
        notificationPreferences: newPrefs
      });
      alert('Notification preferences updated successfully!');
    } catch (error) {
      console.error(error);
      alert('Failed to update preferences.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveProfile = async () => {
    if (!user) return;
    setIsSaving(true);
    try {
      const userRef = doc(db, 'users', user.id);
      await updateDoc(userRef, {
        name: profileData.name,
        phone: profileData.phone,
        city: profileData.city
      }).catch(err => handleFirestoreError(err, 'update', `users/${user.id}`, auth.currentUser));
      
      setUser({
        ...user,
        name: profileData.name,
        phone: profileData.phone,
        city: profileData.city
      });
      alert('Profile updated successfully!');
    } catch (error) {
      console.error(error);
      alert('Failed to update profile.');
    } finally {
      setIsSaving(false);
    }
  };

  useEffect(() => {
    if (!user?.id) return;
    
    const q = query(
      collection(db, 'bookings'),
      where('userId', '==', user.id),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const bs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }) as Booking);
      setBookings(bs);
    });

    return () => unsubscribe();
  }, [user?.id]);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-soft-bg">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-bold text-secondary">Please log in to view your dashboard</h2>
          <Button onClick={() => router.push('/login')}>Log In</Button>
        </div>
      </div>
    );
  }

  const handleLogout = async () => {
    await signOut(auth);
    setUser(null);
    router.push('/');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'pending': return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'completed': return 'bg-purple-900 text-white border-purple-950';
      case 'cancelled': return 'bg-orange-900/10 text-orange-950 border-orange-950/20';
      default: return 'bg-orange-50 text-orange-700 border-orange-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'confirmed': return <CheckCircle size={14} />;
      case 'pending': return <ClockIcon size={14} />;
      case 'completed': return <CheckCircle size={14} />;
      case 'cancelled': return <AlertCircle size={14} />;
      default: return null;
    }
  };

  return (
    <div className="min-h-screen bg-soft-bg pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Sidebar */}
          <aside className="w-full md:w-80 space-y-6">
            <Card className="rounded-[32px] border-none shadow-xl overflow-hidden">
              <div className="bg-secondary p-8 text-center text-white">
                <Avatar className="w-24 h-24 mx-auto mb-4 border-4 border-white/10">
                  <AvatarImage src={`https://api.dicebear.com/7.x/micah/svg?seed=${user.name}`} />
                  <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <h2 className="text-xl font-bold">{user.name}</h2>
                <p className="text-white/60 text-sm">{user.email}</p>
              </div>
              <CardContent className="p-4">
                <nav className="space-y-1">
                  <button 
                    onClick={() => setActiveTab('dashboard')}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-bold transition-all ${
                      activeTab === 'dashboard' ? 'bg-primary/10 text-primary' : 'text-secondary hover:bg-soft-bg'
                    }`}
                  >
                    <LayoutDashboard size={20} />
                    Dashboard
                  </button>
                  <button 
                    onClick={() => setActiveTab('profile')}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-bold transition-all ${
                      activeTab === 'profile' ? 'bg-primary/10 text-primary' : 'text-secondary hover:bg-soft-bg'
                    }`}
                  >
                    <User size={20} />
                    Profile
                  </button>
                  <button 
                    onClick={() => setActiveTab('settings')}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-bold transition-all ${
                      activeTab === 'settings' ? 'bg-primary/10 text-primary' : 'text-secondary hover:bg-soft-bg'
                    }`}
                  >
                    <Settings size={20} />
                    Settings
                  </button>
                  <button 
                    onClick={handleLogout}
                    className="w-full flex items-center gap-3 px-4 py-3 text-secondary hover:bg-orange-50 rounded-2xl font-bold transition-all"
                  >
                    <LogOut size={20} />
                    Logout
                  </button>
                </nav>
              </CardContent>
            </Card>

            <Card className="rounded-[32px] border-none shadow-xl p-8 bg-primary text-white">
              <h3 className="text-lg font-bold mb-2">Need Help?</h3>
              <p className="text-white/80 text-sm mb-6">Our support team is available 24/7 for any queries.</p>
              <Button variant="secondary" className="w-full rounded-xl font-bold">Contact Support</Button>
            </Card>
          </aside>

          {/* Main Content */}
          <main className="flex-1 space-y-8">
            <AnimatePresence mode="wait">
              {activeTab === 'dashboard' && (
                <motion.div
                  key="dashboard"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-8"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h1 className="text-3xl font-display font-bold text-secondary">Your <span className="text-primary">Bookings</span></h1>
                      <p className="text-text-muted">Manage your ongoing and past services.</p>
                    </div>
                    <Button onClick={() => router.push('/dashboard/book')} className="rounded-2xl px-6 h-14 font-bold shadow-lg shadow-primary/20">
                      <Plus className="mr-2" /> New Booking
                    </Button>
                  </div>

                  {bookings.length === 0 ? (
                    <Card className="rounded-[40px] border-dashed border-2 border-gray-200 bg-transparent p-12 text-center">
                      <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6 text-gray-400">
                        <Calendar size={32} />
                      </div>
                      <h3 className="text-xl font-bold text-secondary mb-2">No bookings yet</h3>
                      <p className="text-text-muted mb-8">You haven't booked any services yet. Start by booking your first service today!</p>
                      <Button onClick={() => router.push('/dashboard/book')} className="rounded-2xl px-8 h-14 font-bold">
                        Book Now
                      </Button>
                    </Card>
                  ) : (
                    <div className="grid gap-6">
                      {bookings.map((booking) => (
                        <motion.div
                          key={booking.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                        >
                          <Card className="rounded-[32px] border-none shadow-lg hover:shadow-xl transition-all overflow-hidden group">
                            <CardContent className="p-0">
                              <div className="flex flex-col md:flex-row">
                                <div className="p-8 flex-1 space-y-4">
                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                      <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-2xl">
                                        {booking.service === 'Maid' ? '🧹' : 
                                         booking.service === 'Cook' ? '🍳' : 
                                         booking.service === 'Deep Cleaner' ? '✨' : '👤'}
                                      </div>
                                      <div>
                                        <h3 className="text-xl font-bold text-secondary">{booking.service}</h3>
                                        <p className="text-xs text-text-muted font-bold uppercase tracking-wider">ID: #{booking.id}</p>
                                      </div>
                                    </div>
                                    <Badge className={`px-3 py-1 rounded-full border flex items-center gap-1.5 font-bold ${getStatusColor(booking.status)}`}>
                                      {getStatusIcon(booking.status)}
                                      {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                                    </Badge>
                                  </div>

                                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
                                    <div className="flex items-center gap-2 text-text-muted">
                                      <Calendar size={16} className="text-primary" />
                                      <span className="text-sm font-medium">{booking.date}</span>
                                    </div>
                                    <div className="flex items-center gap-2 text-text-muted">
                                      <ClockIcon size={16} className="text-primary" />
                                      <div className="flex flex-col">
                                        <span className="text-sm font-medium">{booking.time}</span>
                                        {booking.estimatedArrival && (
                                          <span className="text-[10px] text-primary font-bold">Est. Arrival: {booking.estimatedArrival}</span>
                                        )}
                                      </div>
                                    </div>
                                    <div className="flex items-center gap-2 text-text-muted">
                                      <MapPin size={16} className="text-primary" />
                                      <span className="text-sm font-medium truncate">{booking.address}</span>
                                    </div>
                                  </div>
                                </div>
                                <div className="bg-soft-bg p-8 flex flex-col justify-center items-center md:border-l border-gray-100 min-w-[160px]">
                                  <p className="text-xs font-bold text-text-muted uppercase tracking-wider mb-1">Total Paid</p>
                                  <p className="text-2xl font-bold text-secondary">₹{booking.amount + 49}</p>
                                  
                                  {booking.status === 'completed' && !booking.isReviewed && (
                                    <Button 
                                      onClick={() => setSelectedBookingForReview(booking)}
                                      className="mt-4 w-full rounded-xl bg-yellow-500 hover:bg-yellow-600 text-white font-bold h-10"
                                    >
                                      Rate Service
                                    </Button>
                                  )}

                                  <button className="mt-4 text-primary font-bold text-sm flex items-center gap-1 hover:underline">
                                    View Details <ChevronRight size={16} />
                                  </button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}

              {activeTab === 'profile' && (
                <motion.div
                  key="profile"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-8"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h1 className="text-3xl font-display font-bold text-secondary">Profile <span className="text-primary">Settings</span></h1>
                      <p className="text-text-muted">Manage your personal information and preferences.</p>
                    </div>
                  </div>

                  <Card className="rounded-[40px] border-none shadow-xl p-8 md:p-12">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-2">
                        <label className="text-sm font-bold text-secondary uppercase tracking-wider">Full Name</label>
                        <input 
                          type="text" 
                          value={profileData.name} 
                          onChange={(e) => setProfileData({...profileData, name: e.target.value})}
                          className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none font-medium" 
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-bold text-secondary uppercase tracking-wider">Email Address</label>
                        <input type="email" defaultValue={user.email} disabled className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent outline-none font-medium opacity-60" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-bold text-secondary uppercase tracking-wider">Phone Number</label>
                        <input 
                          type="tel" 
                          value={profileData.phone} 
                          onChange={(e) => setProfileData({...profileData, phone: e.target.value})}
                          className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none font-medium" 
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-bold text-secondary uppercase tracking-wider">City</label>
                        <input 
                          type="text" 
                          value={profileData.city} 
                          onChange={(e) => setProfileData({...profileData, city: e.target.value})}
                          className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none font-medium" 
                        />
                      </div>
                    </div>
                    <Button 
                      onClick={handleSaveProfile}
                      disabled={isSaving}
                      className="mt-12 rounded-2xl px-12 py-6 font-bold text-lg shadow-xl shadow-primary/20"
                    >
                      {isSaving ? 'Saving...' : 'Save Profile'}
                    </Button>
                  </Card>
                </motion.div>
              )}

              {activeTab === 'settings' && (
                <motion.div
                  key="settings"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-8"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h1 className="text-3xl font-display font-bold text-secondary">Account <span className="text-primary">Settings</span></h1>
                      <p className="text-text-muted">Manage your notification preferences and security.</p>
                    </div>
                  </div>

                  <div className="grid gap-6">
                    <Card className="rounded-[32px] border-none shadow-lg p-8 group hover:shadow-xl transition-all">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
                            <Bell size={24} />
                          </div>
                          <div>
                            <h3 className="font-bold text-secondary text-lg">Push Notifications</h3>
                            <p className="text-text-muted text-sm">Receive alerts for booking updates and status.</p>
                          </div>
                        </div>
                        <button 
                          onClick={() => setPushEnabled(!pushEnabled)}
                          className={`w-14 h-8 rounded-full relative transition-colors duration-200 ${pushEnabled ? 'bg-primary' : 'bg-gray-200'}`}
                        >
                          <div className={`absolute top-1 w-6 h-6 bg-white rounded-full shadow-md transition-all duration-200 ${pushEnabled ? 'right-1' : 'left-1'}`}></div>
                        </button>
                      </div>
                    </Card>

                    <Card className="rounded-[32px] border-none shadow-lg p-8 group hover:shadow-xl transition-all">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-2xl flex items-center justify-center">
                            <Mail size={24} />
                          </div>
                          <div>
                            <h3 className="font-bold text-secondary text-lg">Email Alerts</h3>
                            <p className="text-text-muted text-sm">Get detailed reports and booking summaries via email.</p>
                          </div>
                        </div>
                        <button 
                          onClick={() => setEmailEnabled(!emailEnabled)}
                          className={`w-14 h-8 rounded-full relative transition-colors duration-200 ${emailEnabled ? 'bg-primary' : 'bg-gray-200'}`}
                        >
                          <div className={`absolute top-1 w-6 h-6 bg-white rounded-full shadow-md transition-all duration-200 ${emailEnabled ? 'right-1' : 'left-1'}`}></div>
                        </button>
                      </div>
                    </Card>

                    <Card className="rounded-[32px] border-none shadow-lg p-8 group hover:shadow-xl transition-all">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-orange-100 text-orange-600 rounded-2xl flex items-center justify-center">
                            <Lock size={24} />
                          </div>
                          <div>
                            <h3 className="font-bold text-secondary text-lg">Change Password</h3>
                            <p className="text-text-muted text-sm">Update your account security credentials.</p>
                          </div>
                        </div>
                        <Button variant="outline" className="rounded-xl font-bold" onClick={() => router.push('/forgot-password')}>Update</Button>
                      </div>
                    </Card>

                    <div className="pt-4">
                      <Button 
                        onClick={handleUpdateNotifications} 
                        disabled={isSaving}
                        className="w-full md:w-auto px-12 rounded-2xl h-14 font-bold shadow-lg shadow-primary/20"
                      >
                        {isSaving ? 'Saving...' : 'Save Notification Preferences'}
                      </Button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </main>
        </div>
      </div>

      <AnimatePresence>
        {selectedBookingForReview && (
          <ReviewModal 
            booking={selectedBookingForReview} 
            onClose={() => setSelectedBookingForReview(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default DashboardPage;
