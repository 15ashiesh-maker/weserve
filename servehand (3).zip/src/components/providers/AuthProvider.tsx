'use client';

import React, { useEffect, useState, useRef } from 'react';
import { onAuthStateChanged, getAuth } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '../../lib/firebase';
import { useStore, User } from '../../store/useStore';

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const setUser = useStore((state) => state.setUser);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [retryCount, setRetryCount] = useState(0);
  const initialized = useRef(false);

  useEffect(() => {
    console.log("AuthProvider: Initializing auth listener...");
    
    // Safety timeout to prevent infinite loading
    const timeout = setTimeout(() => {
      setLoading(false);
      console.warn("AuthProvider: Loading timed out after 5s");
    }, 5000);

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      console.log("AuthProvider: onAuthStateChanged fired", firebaseUser?.uid || 'no user');
      
      try {
        if (firebaseUser) {
          // Standard fetch (non-blocking for UI)
          getDoc(doc(db, 'users', firebaseUser.uid)).then(userDoc => {
            if (userDoc.exists()) {
              const userData = userDoc.data() as User;
              setUser({ ...userData, id: firebaseUser.uid });
            } else {
              setUser({
                id: firebaseUser.uid,
                name: firebaseUser.displayName || 'User',
                email: firebaseUser.email || '',
                role: 'user',
              });
            }
          }).catch(err => {
            console.error("AuthProvider: Firestore error", err);
            setUser({
              id: firebaseUser.uid,
              name: firebaseUser.displayName || 'User',
              email: firebaseUser.email || '',
              role: 'user',
            });
          });
        } else {
          setUser(null);
        }
      } catch (err) {
        console.error("AuthProvider: Auth callback error", err);
      } finally {
        setLoading(false);
        clearTimeout(timeout);
      }
    }, (err) => {
      console.error("AuthProvider: Auth error", err);
      setError(`Auth Error: ${err.message}`);
      setLoading(false);
      clearTimeout(timeout);
    });

    return () => {
      unsubscribe();
      clearTimeout(timeout);
    };
  }, [setUser]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#FFF7ED] text-[#9333EA] font-sans">
        <div className="flex flex-col items-center gap-6 p-8 bg-white rounded-[40px] shadow-2xl max-w-sm w-full text-center">
          <div className="w-16 h-16 border-4 border-[#9333EA] border-t-transparent rounded-full animate-spin"></div>
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-[#3B0764]">ServeHand</h2>
            <p className="text-[#9333EA]/60 font-medium italic">Connecting you to reliable help...</p>
          </div>
          
          <button 
            onClick={() => setLoading(false)}
            className="mt-4 text-xs font-bold uppercase tracking-widest text-[#9333EA]/40 hover:text-[#9333EA] transition-colors"
          >
            Enter Anyway →
          </button>
        </div>
      </div>
    );
  }

  if (error && !initialized.current) { // Only show error if we couldn't even start
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#FFF7ED] text-red-500 font-bold p-8 text-center">
        <div className="space-y-4">
          <p>{error}</p>
          <button 
            onClick={() => { setRetryCount(c => c + 1); setError(null); setLoading(true); initialized.current = false; }}
            className="bg-[#9333EA] text-white px-6 py-2 rounded-xl"
          >
            Retry Connection
          </button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
