import React, { Suspense, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Float, MeshDistortMaterial, Sphere, MeshWobbleMaterial, Points, PointMaterial } from '@react-three/drei';
import * as THREE from 'three';

const ParticleField = () => {
  const points = useRef<THREE.Points>(null!);
  const count = 1000;
  const positions = new Float32Array(count * 3);

  for (let i = 0; i < count; i++) {
    positions[i * 3] = (Math.random() - 0.5) * 20;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 20;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 20;
  }

  useFrame((state) => {
    points.current.rotation.y = state.clock.getElapsedTime() * 0.05;
    points.current.rotation.x = state.clock.getElapsedTime() * 0.02;
  });

  return (
    <Points ref={points} positions={positions} stride={3} frustumCulled={false}>
      <PointMaterial
        transparent
        color="#1E1B4B"
        size={0.05}
        sizeAttenuation={true}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </Points>
  );
};

const ServiceOrb = ({ position, color, label, delay = 0 }: { position: [number, number, number], color: string, label: string, delay?: number }) => {
  const mesh = useRef<THREE.Mesh>(null!);
  
  useFrame((state) => {
    const time = state.clock.getElapsedTime() + delay;
    mesh.current.position.y = position[1] + Math.sin(time) * 0.5;
    mesh.current.rotation.x = time * 0.5;
    mesh.current.rotation.y = time * 0.3;
  });

  return (
    <Float speed={2} rotationIntensity={1} floatIntensity={2}>
      <mesh ref={mesh} position={position}>
        <sphereGeometry args={[0.6, 32, 32]} />
        <MeshDistortMaterial color={color} speed={2} distort={0.4} radius={1} />
      </mesh>
    </Float>
  );
};

const TeamModel = () => {
  return (
    <group position={[0, -1.5, 0]}>
      {/* Central Figure (Maid/Team Lead) */}
      <mesh position={[0, 1.2, 0]}>
        <sphereGeometry args={[0.4, 32, 32]} />
        <meshStandardMaterial color="#1E1B4B" />
      </mesh>
      <mesh position={[0, 0.4, 0]}>
        <cylinderGeometry args={[0.5, 0.3, 1.2, 32]} />
        <meshStandardMaterial color="#334155" />
      </mesh>
      
      {/* Left Figure (Manpower/Technician) */}
      <group position={[-1.2, -0.2, 0.5]}>
        <mesh position={[0, 1, 0]}>
          <sphereGeometry args={[0.35, 32, 32]} />
          <meshStandardMaterial color="#6366F1" />
        </mesh>
        <mesh position={[0, 0.3, 0]}>
          <boxGeometry args={[0.6, 1, 0.4]} />
          <meshStandardMaterial color="#334155" />
        </mesh>
      </group>

      {/* Right Figure (Manpower/Cook) */}
      <group position={[1.2, -0.2, 0.5]}>
        <mesh position={[0, 1, 0]}>
          <sphereGeometry args={[0.35, 32, 32]} />
          <meshStandardMaterial color="#6366F1" />
        </mesh>
        <mesh position={[0, 0.3, 0]}>
          <boxGeometry args={[0.6, 1, 0.4]} />
          <meshStandardMaterial color="#334155" />
        </mesh>
      </group>

      {/* Base Platform */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.2, 0]}>
        <circleGeometry args={[2.5, 64]} />
        <meshStandardMaterial color="#f0f0f0" transparent opacity={0.5} />
      </mesh>
    </group>
  );
};

const HeroScene = () => {
  return (
    <div className="w-full h-[500px] md:h-full relative">
      <Canvas shadows dpr={[1, 2]}>
        <PerspectiveCamera makeDefault position={[0, 0, 8]} fov={50} />
        <OrbitControls enableZoom={false} autoRotate autoRotateSpeed={0.5} />
        
        <ambientLight intensity={0.5} />
        <directionalLight position={[10, 10, 5]} intensity={1} castShadow />
        <pointLight position={[-10, -10, -10]} color="#1E1B4B" intensity={1} />
        <pointLight position={[10, 10, 10]} color="#6366F1" intensity={1} />

        <Suspense fallback={null}>
          <TeamModel />
          <ServiceOrb position={[-3, 2, 1]} color="#1E1B4B" label="Cleaning" delay={0} />
          <ServiceOrb position={[3, 1, 2]} color="#6366F1" label="Cooking" delay={2} />
          <ServiceOrb position={[2, -2, -1]} color="#334155" label="Maid" delay={4} />
          <ParticleField />
        </Suspense>
      </Canvas>
    </div>
  );
};

export default HeroScene;
