import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Utensils, Home, ArrowRight } from 'lucide-react';
import Link from 'next/link';

const services = [
  {
    id: 'maid',
    title: 'Maid Service',
    description: 'Daily household chores, utensil washing, laundry and general help.',
    icon: <Sparkles size={40} />,
    color: 'bg-primary',
    slug: 'maid-service'
  },
  {
    id: 'cooking',
    title: 'Personal Cook',
    description: 'Breakfast, lunch, dinner — as per your diet and preferences.',
    icon: <Utensils size={40} />,
    color: 'bg-secondary',
    slug: 'personal-cook'
  },
  {
    id: 'elderly',
    title: 'Elderly Care',
    description: 'Compassionate care and assistance for your senior family members.',
    icon: <Home size={40} />,
    color: 'bg-accent',
    slug: 'elderly-care'
  },
  {
    id: 'babysitter',
    title: 'Baby Sitter',
    description: 'Professional childcare to keep your little ones safe and happy.',
    icon: <Sparkles size={40} />,
    color: 'bg-primary',
    slug: 'baby-sitter'
  },
  {
    id: 'petcare',
    title: 'Pet Care',
    description: 'Walking, feeding, and grooming for your beloved furry friends.',
    icon: <Utensils size={40} />,
    color: 'bg-secondary',
    slug: 'pet-care'
  },
  {
    id: 'cleaning',
    title: 'Deep Cleaning',
    description: 'Deep clean, regular upkeep, bathroom sanitization and more.',
    icon: <Home size={40} />,
    color: 'bg-accent',
    slug: 'deep-cleaning'
  }
];

const ServicesSection = () => {
  return (
    <section className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-display font-bold text-secondary mb-4"
          >
            Our Professional Services
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-text-muted max-w-2xl mx-auto"
          >
            Choose from our range of verified home services. 
            Each helper is background-checked and trained for excellence.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, i) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -10 }}
              className="group relative p-8 rounded-3xl bg-soft-bg border border-gray-100 hover:shadow-2xl transition-all duration-500"
            >
              <div className={`w-20 h-20 ${service.color} rounded-2xl flex items-center justify-center text-white mb-8 shadow-lg group-hover:scale-110 transition-transform`}>
                {service.icon}
              </div>
              
              <h3 className="text-2xl font-display font-bold text-secondary mb-4">
                {service.title}
              </h3>
              <p className="text-text-muted mb-8 leading-relaxed">
                {service.description}
              </p>
              
              <Link 
                href={service.id === 'cleaning' ? '/deep-cleaning' : '/dashboard/book'}
                className="flex items-center gap-2 font-bold text-primary group-hover:gap-3 transition-all"
              >
                {service.id === 'cleaning' ? 'View Details' : 'Book Now'}
                <ArrowRight size={20} />
              </Link>
              
              {/* Decorative background element */}
              <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-primary/5 rounded-full blur-2xl group-hover:bg-primary/10 transition-colors" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
