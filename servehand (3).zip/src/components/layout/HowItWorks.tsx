'use client';

import React from 'react';
import { motion } from 'motion/react';
import { Search, Calendar, UserCheck, Coffee } from 'lucide-react';

const steps = [
  {
    id: 1,
    title: 'Select Service',
    description: 'Choose from cleaning, cooking, or full-time maid services.',
    icon: <Search size={32} />
  },
  {
    id: 2,
    title: 'Choose Plan',
    description: 'Pick a schedule that fits your needs — hourly, weekly, or monthly.',
    icon: <Calendar size={32} />
  },
  {
    id: 3,
    title: 'Get Matched',
    description: 'We match you with a verified, background-checked helper.',
    icon: <UserCheck size={32} />
  },
  {
    id: 4,
    title: 'Relax',
    description: 'Confirm, pay securely, and enjoy your perfectly cared-for home.',
    icon: <Coffee size={32} />
  }
];

const HowItWorks = () => {
  return (
    <section className="py-24 bg-soft-bg relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-display font-bold text-secondary mb-4"
          >
            How It Works
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-text-muted max-w-2xl mx-auto"
          >
            Booking a professional home service has never been easier. 
            Follow these simple steps to get started.
          </motion.p>
        </div>

        <div className="relative">
          {/* Connecting Line (Desktop) */}
          <div className="hidden lg:block absolute top-1/2 left-0 w-full h-1 bg-gray-200 -translate-y-1/2 -z-10">
            <motion.div 
              initial={{ width: 0 }}
              whileInView={{ width: '100%' }}
              viewport={{ once: true }}
              transition={{ duration: 1.5, ease: "easeInOut" }}
              className="h-full bg-primary"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            {steps.map((step, i) => (
              <motion.div
                key={step.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className="flex flex-col items-center text-center group"
              >
                <div className="relative mb-8">
                  <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center text-primary shadow-xl border-4 border-soft-bg group-hover:scale-110 group-hover:bg-primary group-hover:text-white transition-all duration-500 z-10 relative">
                    {step.icon}
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 bg-secondary text-white rounded-full flex items-center justify-center font-bold text-sm shadow-lg">
                    {step.id}
                  </div>
                </div>
                
                <h3 className="text-xl font-display font-bold text-secondary mb-3">
                  {step.title}
                </h3>
                <p className="text-text-muted leading-relaxed">
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
