import React from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, Zap, UserCheck, Headphones, RefreshCw, Lock } from 'lucide-react';

const features = [
  {
    title: 'Verified & Background-checked',
    description: 'Every helper undergoes strict identity and criminal record verification.',
    icon: <ShieldCheck size={32} />
  },
  {
    title: 'GPS-tracked Real-time Location',
    description: 'Track your helper in real-time as they arrive at your doorstep.',
    icon: <Zap size={32} />
  },
  {
    title: 'Instant Booking in Under 2 Minutes',
    description: 'Our streamlined process gets you the help you need, fast.',
    icon: <UserCheck size={32} />
  },
  {
    title: 'Dedicated Relationship Manager',
    description: 'A personal point of contact for all your queries and needs.',
    icon: <Headphones size={32} />
  },
  {
    title: 'Free Replacement if Unsatisfied',
    description: 'Not happy with the service? We provide a free replacement immediately.',
    icon: <RefreshCw size={32} />
  },
  {
    title: 'Secure Payments (PCI-compliant)',
    description: 'Your transactions are safe with our industry-leading payment partners.',
    icon: <Lock size={32} />
  }
];

const WhyUs = () => {
  return (
    <section className="py-24 bg-soft-bg relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(#1E1B4B_1px,transparent_1px)] [background-size:40px_40px]" />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-display font-bold text-secondary mb-4"
          >
            Why Choose ServeHand?
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-text-muted max-w-2xl mx-auto"
          >
            We prioritize safety, reliability, and quality above all else. 
            Experience the difference of a professional service.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -10 }}
              className="bg-white p-8 rounded-[32px] shadow-xl hover:shadow-2xl transition-all duration-500 group border border-gray-100"
            >
              <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center text-primary mb-6 group-hover:bg-primary group-hover:text-white transition-all duration-500">
                {feature.icon}
              </div>
              <h3 className="text-xl font-display font-bold text-secondary mb-3">
                {feature.title}
              </h3>
              <p className="text-text-muted leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyUs;
