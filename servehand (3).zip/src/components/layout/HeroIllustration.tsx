import React from 'react';
import { motion } from 'motion/react';

const HeroIllustration = () => {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      {/* Central Phone */}
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative z-20 w-[280px] md:w-[320px] aspect-[9/19] bg-secondary rounded-[3.5rem] border-[10px] border-secondary shadow-[0_50px_100px_rgba(0,0,0,0.3)] overflow-hidden"
      >
        <div className="absolute inset-0 bg-secondary flex flex-col items-center justify-center p-6 text-center">
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
            className="text-white font-display text-5xl font-black mb-2 tracking-tighter"
          >
            ServeHand
          </motion.div>
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: 48 }}
            transition={{ delay: 0.8, duration: 0.5 }}
            className="h-1.5 bg-primary rounded-full mb-12" 
          />
          
          <div className="space-y-4 w-full px-4">
            {[1, 2, 3, 4].map((i) => (
              <motion.div 
                key={i} 
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 1 + i * 0.1 }}
                className="h-14 bg-white/10 rounded-2xl w-full flex items-center px-4 gap-3"
              >
                <div className="w-8 h-8 bg-white/20 rounded-lg shrink-0" />
                <div className="h-3 bg-white/20 rounded-full flex-1" />
              </motion.div>
            ))}
          </div>
        </div>
        {/* Notch */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-36 h-8 bg-secondary rounded-b-3xl z-30" />
      </motion.div>

      {/* Floating Maids (Illustrations) - Matching the Snabbit image layout */}
      
      {/* Maid 1: Ironing (Left Bottom) */}
      <motion.div
        initial={{ x: -150, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.8, duration: 0.8, type: "spring" }}
        className="absolute left-[-15%] bottom-[5%] z-30 w-64 md:w-80"
      >
        <img 
          src="https://images.unsplash.com/photo-1582733315328-d46ed997e72b?auto=format&fit=crop&q=80&w=600&h=600" 
          alt="Professional Cleaning"
          className="w-full h-auto rounded-[3rem] shadow-2xl border-8 border-white"
          referrerPolicy="no-referrer"
        />
      </motion.div>

      {/* Maid 2: Cleaning (Right Middle) */}
      <motion.div
        initial={{ x: 150, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 1, duration: 0.8, type: "spring" }}
        className="absolute right-[-10%] top-[20%] z-30 w-64 md:w-80"
      >
        <img 
          src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&q=80&w=600&h=600" 
          alt="Professional Cooking"
          className="w-full h-auto rounded-[3rem] shadow-2xl border-8 border-white"
          referrerPolicy="no-referrer"
        />
      </motion.div>

      {/* Background Elements (Windows/Frames) */}
      <div className="absolute inset-0 -z-10 flex items-center justify-center opacity-10">
        <div className="w-[80%] h-[80%] border-4 border-secondary rounded-3xl" />
        <div className="absolute top-1/4 left-1/4 w-32 h-48 border-2 border-secondary rounded-lg" />
        <div className="absolute bottom-1/4 right-1/4 w-48 h-32 border-2 border-secondary rounded-lg" />
      </div>

      {/* Decorative Circles */}
      <motion.div
        animate={{ scale: [1, 1.1, 1], opacity: [0.1, 0.2, 0.1] }}
        transition={{ duration: 8, repeat: Infinity }}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border-[20px] border-primary/10 rounded-full -z-20"
      />
    </div>
  );
};

export default HeroIllustration;
