'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Navigation, ArrowRight, X } from 'lucide-react';

const LocationBanner = () => {
  const [city, setCity] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [show, setShow] = useState(true);

  const detectLocation = () => {
    setLoading(true);
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          try {
            // In a real app, we'd call a reverse geocoding API here
            // For demo, we'll simulate a city detection
            setTimeout(() => {
              setCity("Noida");
              setLoading(false);
            }, 1500);
          } catch (error) {
            console.error("Error geocoding:", error);
            setLoading(false);
          }
        },
        (error) => {
          console.error("Location error:", error);
          setLoading(false);
        }
      );
    } else {
      setLoading(false);
    }
  };

  if (!show) return null;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-8 left-6 right-6 md:left-auto md:right-8 md:w-96 z-40"
    >
      <div className="bg-secondary text-white p-6 rounded-3xl shadow-2xl relative overflow-hidden group">
        {/* Background glow */}
        <div className="absolute -top-10 -right-10 w-32 h-32 bg-primary/20 rounded-full blur-3xl group-hover:bg-primary/30 transition-colors" />
        
        <button 
          onClick={() => setShow(false)}
          className="absolute top-4 right-4 text-white/50 hover:text-white transition-colors"
        >
          <X size={20} />
        </button>

        <div className="flex flex-col gap-4 relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center shadow-lg">
              <MapPin size={20} />
            </div>
            <div>
              <h4 className="font-bold text-lg">Location Check</h4>
              <p className="text-xs text-white/70">Find helpers near you</p>
            </div>
          </div>

          {city ? (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col gap-3"
            >
              <p className="text-sm leading-relaxed">
                Great news! We serve in <span className="text-primary font-bold">{city}</span>. 
                View available helpers near you right now.
              </p>
              <button className="bg-white text-secondary px-6 py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-primary hover:text-white transition-all">
                View Helpers
                <ArrowRight size={18} />
              </button>
            </motion.div>
          ) : (
            <div className="flex flex-col gap-3">
              <p className="text-sm text-white/80">
                Enable location to see verified maids, cleaners and cooks available in your area.
              </p>
              <button 
                onClick={detectLocation}
                disabled={loading}
                className="bg-primary text-white px-6 py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-primary/90 transition-all disabled:opacity-50"
              >
                {loading ? (
                  <span className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Detecting...
                  </span>
                ) : (
                  <>
                    <Navigation size={18} />
                    Auto-Detect Location
                  </>
                )}
              </button>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default LocationBanner;
