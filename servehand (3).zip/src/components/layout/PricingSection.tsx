'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Check, Info, Calculator, ArrowRight } from 'lucide-react';
import Link from 'next/link';

const plans = [
  {
    id: 'instant',
    title: 'Instant Service',
    price: '₹100',
    unit: 'starting per hour',
    features: [
      'Min. 1 hour booking',
      'Book same-day',
      'Flexible timing',
      'Verified professionals'
    ],
    color: 'border-gray-100',
    buttonText: 'Book Now'
  },
  {
    id: 'weekly',
    title: 'Weekly Plan',
    price: '₹100',
    unit: 'per hour/day',
    features: [
      'Choose specific days',
      'Set preferred time slots',
      'Auto-renews monthly',
      'Cancel anytime'
    ],
    color: 'border-gray-100',
    buttonText: 'Select Days'
  },
  {
    id: 'monthly',
    title: 'Monthly Plan',
    price: '₹2,500',
    unit: 'per adult/month',
    features: [
      'Dedicated helper',
      'Priority support',
      'Free replacement',
      'Save ₹500 on combo'
    ],
    color: 'border-primary border-2',
    highlight: true,
    buttonText: 'Most Popular'
  },
  {
    id: 'custom',
    title: 'Custom Plan',
    price: 'Custom',
    unit: 'pricing',
    features: [
      'Build your own package',
      'Mix services & schedules',
      'Dynamic calculation',
      'Dedicated manager'
    ],
    color: 'border-gray-100',
    buttonText: 'Build Plan'
  }
];

const PricingSection = () => {
  const [adults, setAdults] = useState(2);
  const [serviceType, setServiceType] = useState<'single' | 'both'>('single');

  const calculateEstimate = () => {
    const baseRate = serviceType === 'both' ? 4500 : 2500;
    return baseRate * adults;
  };

  return (
    <section className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-display font-bold text-secondary mb-4"
          >
            Simple, Transparent Pricing
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-text-muted max-w-2xl mx-auto"
          >
            No hidden fees. Choose a plan that fits your lifestyle and budget.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {plans.map((plan, i) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -10 }}
              className={`p-8 rounded-3xl bg-white shadow-xl flex flex-col ${plan.color} relative overflow-hidden group`}
            >
              {plan.highlight && (
                <div className="absolute top-0 right-0 bg-primary text-white px-4 py-1 rounded-bl-xl font-bold text-xs uppercase tracking-widest">
                  Popular
                </div>
              )}
              
              <h3 className="text-xl font-display font-bold text-secondary mb-2">{plan.title}</h3>
              <div className="flex items-baseline gap-1 mb-8">
                <span className="text-4xl font-bold text-primary">{plan.price}</span>
                <span className="text-text-muted text-sm">{plan.unit}</span>
              </div>

              <ul className="flex flex-col gap-4 mb-10 flex-1">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-sm text-text-muted">
                    <div className="mt-1 w-5 h-5 bg-accent/10 rounded-full flex items-center justify-center text-accent shrink-0">
                      <Check size={12} strokeWidth={3} />
                    </div>
                    {feature}
                  </li>
                ))}
              </ul>

              <Link 
                href="/dashboard/book"
                className={`w-full py-4 rounded-xl font-bold text-center transition-all ${
                  plan.highlight 
                    ? 'bg-primary text-white shadow-lg shadow-primary/30 hover:bg-primary/90' 
                    : 'bg-soft-bg text-secondary hover:bg-secondary hover:text-white'
                }`}
              >
                {plan.buttonText}
              </Link>
            </motion.div>
          ))}
        </div>

        {/* Pricing Calculator */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-secondary p-8 md:p-12 rounded-[40px] text-white shadow-2xl relative overflow-hidden"
        >
          {/* Background Pattern */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 rounded-full blur-3xl" />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative z-10">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-primary rounded-2xl flex items-center justify-center">
                  <Calculator size={24} />
                </div>
                <h3 className="text-3xl font-display font-bold">Price Calculator</h3>
              </div>
              <p className="text-white/70 mb-8 leading-relaxed">
                Estimate your monthly cost based on your household size and service requirements.
              </p>

              <div className="flex flex-col gap-8">
                <div>
                  <label className="block text-sm font-bold uppercase tracking-widest text-white/50 mb-4">Number of Adults</label>
                  <div className="flex items-center gap-6">
                    <button 
                      onClick={() => setAdults(Math.max(1, adults - 1))}
                      className="w-12 h-12 rounded-xl border-2 border-white/20 flex items-center justify-center text-2xl font-bold hover:bg-white/10 transition-colors"
                    >
                      -
                    </button>
                    <span className="text-4xl font-bold w-12 text-center">{adults}</span>
                    <button 
                      onClick={() => setAdults(adults + 1)}
                      className="w-12 h-12 rounded-xl border-2 border-white/20 flex items-center justify-center text-2xl font-bold hover:bg-white/10 transition-colors"
                    >
                      +
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold uppercase tracking-widest text-white/50 mb-4">Services Needed</label>
                  <div className="flex flex-wrap gap-4">
                    <button 
                      onClick={() => setServiceType('single')}
                      className={`px-6 py-3 rounded-xl font-bold transition-all ${
                        serviceType === 'single' ? 'bg-primary text-white' : 'bg-white/10 text-white hover:bg-white/20'
                      }`}
                    >
                      Cleaning OR Cooking
                    </button>
                    <button 
                      onClick={() => setServiceType('both')}
                      className={`px-6 py-3 rounded-xl font-bold transition-all ${
                        serviceType === 'both' ? 'bg-primary text-white' : 'bg-white/10 text-white hover:bg-white/20'
                      }`}
                    >
                      Both Services (Save ₹500)
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white/10 p-8 rounded-3xl border border-white/10 flex flex-col items-center text-center">
              <p className="text-white/50 font-bold uppercase tracking-widest mb-2">Estimated Monthly Cost</p>
              <div className="flex items-baseline gap-2 mb-8">
                <span className="text-6xl font-bold text-primary">₹{calculateEstimate().toLocaleString()}</span>
                <span className="text-white/50">/ month</span>
              </div>
              <div className="flex flex-col gap-4 w-full">
                <Link 
                  href="/dashboard/book"
                  className="bg-white text-secondary py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-primary hover:text-white transition-all shadow-xl"
                >
                  Book with this Plan
                  <ArrowRight size={20} />
                </Link>
                <p className="text-xs text-white/40 flex items-center justify-center gap-1">
                  <Info size={12} />
                  Final price may vary based on specific requirements
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default PricingSection;
