'use client';

import React from 'react';
import { motion } from 'motion/react';
import { Search, MapPin, CheckCircle, ArrowRight, Star, ShieldCheck, Zap } from 'lucide-react';
import HeroIllustration from './HeroIllustration';
import Link from 'next/link';

const Hero = () => {
  const containerVariants: any = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants: any = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] }
    }
  };

  return (
    <section className="relative min-h-screen pt-32 pb-20 overflow-hidden flex items-center bg-white">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-full -z-10 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] right-[-5%] w-[600px] h-[600px] bg-primary/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] left-[-5%] w-[500px] h-[500px] bg-accent/5 rounded-full blur-[100px]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:40px_40px] opacity-30" />
      </div>

      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
        {/* Left Content */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="flex flex-col gap-8 relative z-40"
        >
          <div className="space-y-6">
            <motion.div
              variants={itemVariants}
              className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full font-bold text-xs uppercase tracking-[0.2em] shadow-sm"
            >
              <Zap size={14} className="fill-primary" />
              India's Most Trusted Home Help
            </motion.div>
            
            <motion.h1 
              variants={itemVariants}
              className="text-6xl md:text-7xl lg:text-8xl font-display font-black text-secondary leading-[0.95] tracking-tighter"
            >
              Reliable Help, <br />
              <span className="text-primary italic">Simplified.</span>
            </motion.h1>
            
            <motion.p 
              variants={itemVariants}
              className="text-xl text-text-muted max-w-lg leading-relaxed font-medium"
            >
              Book verified, background-checked maids, cooks, and cleaners in Noida. 
              Premium service, transparent pricing, zero stress.
            </motion.p>
          </div>

          {/* Quick Search/Action */}
          <motion.div 
            variants={itemVariants}
            className="flex flex-col sm:flex-row items-center gap-4"
          >
            <Link 
              href="/dashboard/book"
              className="w-full sm:w-auto bg-primary text-white px-10 py-5 rounded-2xl font-bold text-lg shadow-[0_20px_40px_rgba(139,92,246,0.3)] hover:bg-primary/90 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-3 group"
            >
              Book a Service
              <ArrowRight size={22} className="group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link 
              href="/how-it-works"
              className="w-full sm:w-auto bg-white text-secondary border-2 border-secondary/5 px-10 py-5 rounded-2xl font-bold text-lg hover:bg-secondary/5 transition-all flex items-center justify-center gap-2"
            >
              How it works
            </Link>
          </motion.div>

          {/* Trust Indicators */}
          <motion.div 
            variants={itemVariants}
            className="pt-8 border-t border-gray-100"
          >
            <div className="flex flex-col gap-6">
              <div className="flex items-center gap-4">
                <div className="flex -space-x-3">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="w-12 h-12 rounded-full border-4 border-white overflow-hidden bg-gray-200 shadow-sm">
                      <img 
                        src={`https://i.pravatar.cc/150?u=${i + 20}`} 
                        alt="User" 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  ))}
                  <div className="w-12 h-12 rounded-full border-4 border-white bg-secondary flex items-center justify-center text-white text-xs font-bold shadow-sm">
                    +10k
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-1 text-yellow-400">
                    {[1, 2, 3, 4, 5].map((i) => <Star key={i} size={16} fill="currentColor" />)}
                  </div>
                  <p className="text-sm font-bold text-secondary">Trusted by 10,000+ households</p>
                </div>
              </div>

              <div className="flex flex-wrap gap-x-8 gap-y-4">
                <div className="flex items-center gap-2 text-text-muted">
                  <ShieldCheck size={18} className="text-orange-500" />
                  <span className="text-sm font-bold">100% Verified</span>
                </div>
                <div className="flex items-center gap-2 text-text-muted">
                  <CheckCircle size={18} className="text-orange-500" />
                  <span className="text-sm font-bold">No Hidden Fees</span>
                </div>
                <div className="flex items-center gap-2 text-text-muted">
                  <Zap size={18} className="text-orange-500" />
                  <span className="text-sm font-bold">Instant Booking</span>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>

        {/* Right Content - Illustration */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="relative h-[500px] lg:h-[700px] flex items-center justify-center"
        >
          <HeroIllustration />
          
          {/* Floating Experience Card */}
          <motion.div
            animate={{ y: [0, -15, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -top-4 -right-4 bg-white p-6 rounded-3xl shadow-2xl border border-gray-50 flex flex-col gap-2 z-50"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center text-orange-600">
                <ShieldCheck size={20} />
              </div>
              <span className="font-bold text-secondary">Safety First</span>
            </div>
            <p className="text-xs text-text-muted font-medium max-w-[150px]">
              Every helper undergoes a 3-step verification process.
            </p>
          </motion.div>

          {/* Floating Service Card */}
          <motion.div
            animate={{ y: [0, 15, 0] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
            className="absolute bottom-10 -left-10 bg-white p-6 rounded-3xl shadow-2xl border border-gray-50 flex items-center gap-4 z-50"
          >
            <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
              <MapPin size={24} />
            </div>
            <div>
              <p className="text-[10px] font-bold text-text-muted uppercase tracking-wider">Available in</p>
              <p className="text-lg font-bold text-secondary">Noida & Delhi</p>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
