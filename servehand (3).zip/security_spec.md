# Security Specification

## Data Invariants
1. A User document can only be created by the owner (UID matches).
2. Users cannot modify their role after creation.
3. Bookings must belong to a valid user. User must be logged in to create.
4. Messages can be created by anyone (or only logged in users?). The prompt asks to save details, contact details. Anyone can submit contact details, so no auth required to write ContactMessages.
5. All IDs must be strictly validated.
6. A Booking's `amount` and `service` cannot be arbitrarily changed after creation unless authorized.
7. Timestamps must use `request.time`.

## The "Dirty Dozen" Payloads
1. Create user with mismatching UID.
2. Update user to elevate role to Admin.
3. Create booking lacking required fields.
4. Update booking to steal it (change userId).
5. Modify booking without correct schema.
6. Insert 1MB junk string in ID fields.
7. Missing timestamp.
8. Modifying a completed booking (terminal state).
9. Modifying another person's user doc.
10. Contact form payload missing required schema.
11. PII data leak via broad list access.
12. Creating a user with an unknown role.

## The Test Runner
See `firestore.rules.test.ts` for full implementation.
