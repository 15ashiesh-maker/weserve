/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Use tsconfig for aliases instead of webpack config
};

export default nextConfig;
