'use client';
import DeepCleaningPage from '../../src/views/DeepCleaningPage';
export default function Page() { return <DeepCleaningPage />; }
