'use client';
import HowItWorksPage from '../../src/views/HowItWorksPage';
export default function Page() { return <HowItWorksPage />; }
