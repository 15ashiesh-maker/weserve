'use client';
import WhyUsPage from '../../src/views/WhyUsPage';
export default function Page() { return <WhyUsPage />; }
