'use client';
import ServiceProviderOnboardingPage from '../../src/views/ServiceProviderOnboardingPage';
export default function Page() { return <ServiceProviderOnboardingPage />; }
