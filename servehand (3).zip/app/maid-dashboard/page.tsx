'use client';
import MaidDashboardPage from '../../src/views/MaidDashboardPage';
export default function Page() { return <MaidDashboardPage />; }
