import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    status: "success",
    message: "ServeHand API is running on Next.js",
    timestamp: new Date().toISOString()
  });
}
