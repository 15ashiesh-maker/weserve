'use client';

import React from 'react';
import Hero from '../src/components/layout/Hero';
import ServiceShowcase3D from '../src/components/layout/ServiceShowcase3D';
import HowItWorks from '../src/components/layout/HowItWorks';
import PricingSection from '../src/components/layout/PricingSection';
import WhyUs from '../src/components/layout/WhyUs';
import Testimonials from '../src/components/layout/Testimonials';
import FAQ from '../src/components/layout/FAQ';
import Footer from '../src/components/layout/Footer';
import LocationBanner from '../src/components/layout/LocationBanner';

export default function Home() {
  return (
    <main>
      <Hero />
      <ServiceShowcase3D />
      <HowItWorks />
      <PricingSection />
      <WhyUs />
      <Testimonials />
      <FAQ />
      <Footer />
      <LocationBanner />
    </main>
  );
}
