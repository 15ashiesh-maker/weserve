'use client';
import BookingPage from '../../../src/views/BookingPage';
export default function Page() { return <BookingPage />; }
