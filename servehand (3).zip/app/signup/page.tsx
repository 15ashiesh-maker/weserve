'use client';
import SignupPage from '../../src/views/SignupPage';
export default function Page() { return <SignupPage />; }
