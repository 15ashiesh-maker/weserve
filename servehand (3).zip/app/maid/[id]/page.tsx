'use client';
import { useParams } from 'next/navigation';
import MaidProfilePage from '../../../src/views/MaidProfilePage';
export default function Page() {
  const params = useParams();
  // MaidProfilePage usually gets ID from useParams of react-router
  // We might need to adjust it to take ID as a prop or rely on Next's useParams if we patch it
  return <MaidProfilePage />;
}
