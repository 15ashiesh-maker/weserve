import './globals.css';
import { AuthProvider } from '../src/components/providers/AuthProvider';
import Navbar from '../src/components/layout/Navbar';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'ServeHand - House Management & Concierge Services',
  description: 'Premium cleaning, cooking, and errand services at your fingertips.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen flex flex-col selection:bg-primary selection:text-white">
        <AuthProvider>
          <Navbar />
          {children}
        </AuthProvider>
      </body>
    </html>
  );
}
