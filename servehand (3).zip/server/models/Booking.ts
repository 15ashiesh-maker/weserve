import mongoose from 'mongoose';

const bookingSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  serviceType: { type: String, enum: ['cleaning', 'cooking', 'maid', 'both'], required: true },
  planType: { type: String, enum: ['instant', 'weekly', 'monthly', 'custom'], required: true },
  maidId: { type: mongoose.Schema.Types.ObjectId, ref: 'Maid' },
  scheduledDates: [{ type: Date, required: true }],
  timeSlot: { type: String, required: true },
  duration: { type: Number, required: true }, // in hours
  address: {
    street: String,
    city: String,
    state: String,
    pincode: String,
    coordinates: { lat: Number, lng: Number }
  },
  status: { 
    type: String, 
    enum: ['pending', 'confirmed', 'on-way', 'in-progress', 'completed', 'cancelled'],
    default: 'pending'
  },
  paymentId: String,
  razorpayOrderId: String,
  amount: { type: Number, required: true },
  numberOfAdults: { type: Number, default: 1 },
  notes: String,
  review: {
    rating: { type: Number, min: 1, max: 5 },
    comment: String,
    createdAt: Date
  },
  createdAt: { type: Date, default: Date.now }
});

const Booking = mongoose.model('Booking', bookingSchema);
export default Booking;
