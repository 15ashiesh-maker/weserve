import mongoose from 'mongoose';

const maidSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true, select: false },
  phone: { type: String, required: true, unique: true },
  photo: { type: String },
  currentAddress: { type: String },
  permanentAddress: { type: String },
  aadharNumber: { type: String },
  familyDetails: { type: String },
  policeVerification: { type: String },
  services: [{ type: String, enum: ['cleaning', 'cooking', 'maid'] }],
  rating: { type: Number, default: 4.5, min: 1, max: 5 },
  isAvailable: { type: Boolean, default: true },
  location: {
    type: { type: String, enum: ['Point'], default: 'Point' },
    coordinates: { type: [Number], required: true } // [lng, lat]
  },
  experience: { type: Number, required: true }, // in years
  languages: [String],
  isVerified: { type: Boolean, default: false },
  documents: [String], // URLs to background check docs
  role: { type: String, default: 'maid' },
  createdAt: { type: Date, default: Date.now }
});

maidSchema.pre('save', async function(this: any) {
  if (!this.isModified('password')) return;
  const bcrypt = await import('bcrypt');
  this.password = await bcrypt.default.hash(this.password, 12);
});

maidSchema.methods.comparePassword = async function(candidatePassword, userPassword) {
  const bcrypt = await import('bcrypt');
  return await bcrypt.default.compare(candidatePassword, userPassword);
};

maidSchema.index({ location: '2dsphere' });

const Maid = mongoose.model('Maid', maidSchema);
export default Maid;
