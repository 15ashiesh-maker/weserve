import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, User, LogIn, Calendar, LayoutDashboard, LogOut } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { auth } from '../../lib/firebase';
import { signOut } from 'firebase/auth';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const user = useStore((state) => state.user);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Services', path: '/services' },
    { name: 'About Us', path: '/about' },
    { name: 'How It Works', path: '/how-it-works' },
    { name: 'Pricing', path: '/pricing' },
    { name: 'Why Us', path: '/why-us' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <nav
      className={cn(
        'fixed top-6 left-1/2 -translate-x-1/2 z-50 transition-all duration-500 w-[95%] max-w-7xl rounded-3xl border border-white/20',
        scrolled 
          ? 'glass py-3 shadow-[0_20px_50px_rgba(0,0,0,0.1)] backdrop-blur-xl bg-white/70' 
          : 'bg-white/40 py-4 backdrop-blur-md'
      )}
    >
      <div className="px-6 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3 group">
          <motion.div 
            whileHover={{ rotateY: 180 }}
            transition={{ duration: 0.6 }}
            className="w-12 h-12 bg-primary rounded-2xl flex items-center justify-center text-white font-bold text-2xl shadow-xl"
          >
            SH
          </motion.div>
          <div className="flex flex-col -gap-1">
            <span className="font-display text-2xl font-black tracking-tighter text-secondary leading-none">
              Serve<span className="text-accent">Hand</span>
            </span>
            <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-text-muted leading-none">
              Home Services
            </span>
          </div>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-1 bg-secondary/5 p-1 rounded-2xl border border-secondary/5">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              className={cn(
                'px-4 py-2 rounded-xl font-bold text-sm transition-all duration-300',
                location.pathname === link.path 
                  ? 'bg-white text-primary shadow-sm' 
                  : 'text-secondary hover:bg-white/50 hover:text-primary'
              )}
            >
              {link.name}
            </Link>
          ))}
        </div>

        {/* Actions */}
        <div className="hidden md:flex items-center gap-4">
          {user ? (
            <div className="flex items-center gap-4">
              <Link
                to={user.role === 'maid' ? "/maid-dashboard" : "/dashboard"}
                className="flex items-center gap-2 group px-2 py-2"
              >
                <Avatar className="w-10 h-10 border-2 border-primary/20 group-hover:border-primary transition-all">
                  <AvatarImage src={user.photoUrl} alt={user.name} />
                  <AvatarFallback className="bg-primary/10 text-primary font-bold">
                    {user.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div className="flex flex-col">
                  <span className="text-xs font-black text-secondary leading-none">{user.name.split(' ')[0]}</span>
                  <span className="text-[10px] font-bold text-primary/70 uppercase tracking-tighter">
                    {user.role === 'maid' ? 'Pro Dashboard' : 'Dashboard'}
                  </span>
                </div>
              </Link>
              
              <button
                onClick={() => signOut(auth).then(() => useStore.getState().logout())}
                className="p-2.5 text-text-muted hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
                title="Logout"
              >
                <LogOut size={20} />
              </button>
            </div>
          ) : (
            <Link
              to="/login"
              className="flex items-center gap-2 px-4 py-2 font-bold text-secondary hover:text-primary transition-all"
            >
              <LogIn size={18} />
              Login
            </Link>
          )}
          
          <Link
            to={user?.role === 'maid' ? "/maid-dashboard" : "/dashboard/book"}
            className="bg-primary text-white px-6 py-2.5 rounded-2xl font-bold shadow-[0_10px_20px_rgba(30,27,75,0.3)] hover:bg-primary/90 hover:scale-105 active:scale-95 transition-all flex items-center gap-2"
          >
            {user?.role === 'maid' ? (
              <>
                <LayoutDashboard size={18} />
                My Dashboard
              </>
            ) : (
              <>
                <Calendar size={18} />
                Book Now
              </>
            )}
          </Link>
        </div>

        {/* Mobile Toggle */}
        <button
          className="md:hidden p-2 text-secondary flex items-center gap-2"
          onClick={() => setIsOpen(!isOpen)}
        >
          {user && !isOpen && (
            <Avatar className="w-8 h-8 border border-primary/20">
              <AvatarImage src={user.photoUrl} alt={user.name} />
              <AvatarFallback className="text-[10px] bg-primary/10 text-primary">
                {user.name.charAt(0)}
              </AvatarFallback>
            </Avatar>
          )}
          {isOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 right-0 bg-white shadow-2xl p-6 flex flex-col gap-6 md:hidden border-t border-gray-100 rounded-b-[32px] mt-2"
          >
            {user && (
              <div className="flex items-center gap-4 p-4 bg-soft-bg rounded-2xl border border-gray-50">
                <Avatar className="w-12 h-12">
                  <AvatarImage src={user.photoUrl} alt={user.name} />
                  <AvatarFallback className="bg-primary/10 text-primary font-bold">
                    {user.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-bold text-secondary">{user.name}</p>
                  <p className="text-xs text-text-muted">{user.email}</p>
                </div>
              </div>
            )}
            
            <div className="grid grid-cols-1 gap-1">
              {navLinks.map((link, i) => (
                <motion.div
                  key={link.name}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                >
                  <Link
                    to={link.path}
                    onClick={() => setIsOpen(false)}
                    className="px-4 py-3 font-bold text-secondary hover:bg-soft-bg rounded-xl block transition-colors"
                  >
                    {link.name}
                  </Link>
                </motion.div>
              ))}
            </div>

            <hr className="border-gray-100" />
            
            <div className="flex flex-col gap-3">
              {user ? (
                <>
                  <Link
                    to={user.role === 'maid' ? "/maid-dashboard" : "/dashboard"}
                    onClick={() => setIsOpen(false)}
                    className="flex items-center gap-3 px-4 py-3 font-bold text-secondary hover:bg-soft-bg rounded-xl transition-colors"
                  >
                    <LayoutDashboard size={20} className="text-primary" />
                    Dashboard
                  </Link>
                  <button
                    onClick={() => {
                      setIsOpen(false);
                      signOut(auth).then(() => useStore.getState().logout());
                    }}
                    className="flex items-center gap-3 px-4 py-3 font-bold text-red-500 hover:bg-red-50 rounded-xl transition-colors text-left"
                  >
                    <LogOut size={20} />
                    Logout
                  </button>
                </>
              ) : (
                <Link
                  to="/login"
                  onClick={() => setIsOpen(false)}
                  className="flex items-center gap-3 px-4 py-3 font-bold text-secondary hover:bg-soft-bg rounded-xl transition-colors"
                >
                  <LogIn size={20} className="text-primary" />
                  Login
                </Link>
              )}
              <Link
                to={user?.role === 'maid' ? "/maid-dashboard" : "/dashboard/book"}
                onClick={() => setIsOpen(false)}
                className="bg-primary text-white px-6 py-4 rounded-2xl font-bold text-center text-lg shadow-xl shadow-primary/20 flex items-center justify-center gap-2"
              >
                {user?.role === 'maid' ? (
                  <>
                    <LayoutDashboard size={20} />
                    My Dashboard
                  </>
                ) : (
                  <>
                    <Calendar size={20} />
                    Book Now
                  </>
                )}
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
