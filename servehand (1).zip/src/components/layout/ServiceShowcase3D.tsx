import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Star, ShieldCheck, Clock, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const services = [
  {
    id: 1,
    title: 'Professional Maid',
    description: 'Expert help for your daily household chores. From dusting to laundry, we handle it all with care.',
    image: 'https://images.unsplash.com/photo-1581578731548-c64695cc6958?auto=format&fit=crop&q=80&w=800&h=1000',
    rating: 4.9,
    reviews: '2.5k+',
    color: 'bg-primary'
  },
  {
    id: 2,
    title: 'Expert Cook',
    description: 'Delicious, home-cooked meals tailored to your taste and health requirements. Professional hygiene standards.',
    image: 'https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&q=80&w=800&h=1000',
    rating: 4.8,
    reviews: '1.8k+',
    color: 'bg-secondary'
  },
  {
    id: 3,
    title: 'Deep Cleaning',
    description: 'Thorough cleaning of every corner of your home using professional-grade equipment and eco-friendly products.',
    image: 'https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?auto=format&fit=crop&q=80&w=800&h=1000',
    rating: 4.9,
    reviews: '3.2k+',
    color: 'bg-accent'
  },
  {
    id: 4,
    title: 'Elderly Care',
    description: 'Compassionate and professional care for your elders. We provide medical assistance and companionship.',
    image: 'https://images.unsplash.com/photo-1581578017093-cd305ce66ac4?auto=format&fit=crop&q=80&w=800&h=1000',
    rating: 5.0,
    reviews: '1.2k+',
    color: 'bg-primary'
  },
  {
    id: 5,
    title: 'Baby Sitting',
    description: 'Verified and trained sitters who love kids. Safe, engaging, and reliable care for your little ones.',
    image: 'https://images.unsplash.com/photo-1596464716127-f2a82984de30?auto=format&fit=crop&q=80&w=800&h=1000',
    rating: 4.7,
    reviews: '900+',
    color: 'bg-secondary'
  }
];

const ServiceShowcase3D = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);
  const navigate = useNavigate();

  const next = () => {
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % services.length);
  };

  const prev = () => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + services.length) % services.length);
  };

  useEffect(() => {
    const timer = setInterval(next, 8000); // Increased time for better readability
    return () => clearInterval(timer);
  }, [currentIndex]); // Reset interval when manually changed

  const variants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0,
      scale: 0.5,
      rotateY: direction > 0 ? 45 : -45,
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
      scale: 1,
      rotateY: 0,
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0,
      scale: 0.5,
      rotateY: direction < 0 ? 45 : -45,
    })
  };

  return (
    <section className="py-24 bg-white overflow-hidden perspective-1000">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-6xl font-display font-bold text-secondary mb-4"
          >
            Our <span className="text-primary">Premium</span> Offerings
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-text-muted max-w-2xl mx-auto"
          >
            Experience the future of home services with our 3D-verified professionals.
          </motion.p>
        </div>

        <div className="relative h-[600px] flex items-center justify-center">
          <AnimatePresence initial={false} custom={direction}>
            <motion.div
              key={currentIndex}
              custom={direction}
              variants={variants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{
                x: { type: "spring", stiffness: 300, damping: 30 },
                opacity: { duration: 0.2 },
                scale: { duration: 0.4 },
                rotateY: { duration: 0.4 }
              }}
              className="absolute w-full max-w-4xl grid grid-cols-1 lg:grid-cols-2 gap-12 items-center bg-soft-bg p-8 md:p-12 rounded-[50px] shadow-2xl border border-gray-100"
            >
              {/* Left: Image with 3D effect */}
              <div className="relative group">
                <motion.div 
                  whileHover={{ rotateY: 10, rotateX: -5 }}
                  className="relative z-10 rounded-[40px] overflow-hidden shadow-2xl aspect-[4/5]"
                >
                  <img 
                    src={services[currentIndex].image} 
                    alt={services[currentIndex].title}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute bottom-6 left-6 right-6 flex justify-between items-end">
                    <div className="flex items-center gap-2 bg-white/20 backdrop-blur-md px-4 py-2 rounded-full border border-white/30">
                      <Star className="text-yellow-400 fill-yellow-400" size={16} />
                      <span className="text-white font-bold">{services[currentIndex].rating}</span>
                    </div>
                    <div className="text-white text-right">
                      <p className="text-xs font-bold uppercase tracking-widest opacity-70">Reviews</p>
                      <p className="text-lg font-bold">{services[currentIndex].reviews}</p>
                    </div>
                  </div>
                </motion.div>
                {/* Decorative elements */}
                <div className="absolute -top-6 -left-6 w-24 h-24 bg-primary/10 rounded-full blur-2xl" />
                <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-secondary/10 rounded-full blur-2xl" />
              </div>

              {/* Right: Content */}
              <div className="space-y-8">
                <div className="space-y-4">
                  <motion.div 
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 text-primary rounded-full font-bold text-sm uppercase tracking-widest"
                  >
                    <ShieldCheck size={16} />
                    Verified Service
                  </motion.div>
                  <motion.h3 
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1 }}
                    className="text-4xl md:text-5xl font-display font-bold text-secondary"
                  >
                    {services[currentIndex].title}
                  </motion.h3>
                  <motion.p 
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 }}
                    className="text-xl text-text-muted leading-relaxed"
                  >
                    {services[currentIndex].description}
                  </motion.p>
                </div>

                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="grid grid-cols-2 gap-4"
                >
                  <div className="flex items-center gap-3 p-4 bg-white rounded-2xl shadow-sm border border-gray-50">
                    <Clock className="text-primary" size={24} />
                    <div>
                      <p className="text-xs font-bold text-text-muted uppercase tracking-wider">Arrival</p>
                      <p className="text-sm font-bold text-secondary">Under 30m</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-white rounded-2xl shadow-sm border border-gray-50">
                    <CheckCircle className="text-primary" size={24} />
                    <div>
                      <p className="text-xs font-bold text-text-muted uppercase tracking-wider">Status</p>
                      <p className="text-sm font-bold text-secondary">Available</p>
                    </div>
                  </div>
                </motion.div>

                <motion.button 
                  onClick={() => navigate('/dashboard/book', { state: { service: services[currentIndex].title } })}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-full bg-secondary text-white py-5 rounded-2xl font-bold text-lg shadow-xl hover:bg-secondary/90 transition-all flex items-center justify-center gap-2"
                >
                  Book {services[currentIndex].title}
                </motion.button>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Controls */}
          <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 flex gap-6 z-30">
            <button 
              onClick={(e) => {
                e.stopPropagation();
                prev();
              }}
              className="w-16 h-16 rounded-full bg-white shadow-2xl border border-gray-100 flex items-center justify-center text-secondary hover:text-primary hover:scale-110 active:scale-95 transition-all cursor-pointer group"
              aria-label="Previous service"
            >
              <ChevronLeft size={28} className="group-hover:-translate-x-1 transition-transform" />
            </button>
            <button 
              onClick={(e) => {
                e.stopPropagation();
                next();
              }}
              className="w-16 h-16 rounded-full bg-white shadow-2xl border border-gray-100 flex items-center justify-center text-secondary hover:text-primary hover:scale-110 active:scale-95 transition-all cursor-pointer group"
              aria-label="Next service"
            >
              <ChevronRight size={28} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>

        {/* Indicators */}
        <div className="flex justify-center gap-3 mt-12">
          {services.map((_, i) => (
            <button
              key={i}
              onClick={() => {
                setDirection(i > currentIndex ? 1 : -1);
                setCurrentIndex(i);
              }}
              className={`h-2 rounded-full transition-all duration-500 ${i === currentIndex ? 'w-12 bg-primary' : 'w-2 bg-gray-200 hover:bg-gray-300'}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServiceShowcase3D;
