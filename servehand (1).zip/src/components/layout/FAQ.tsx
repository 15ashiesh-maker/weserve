import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Minus } from 'lucide-react';

const faqs = [
  {
    question: 'How do you verify the maids and cooks?',
    answer: 'We conduct a multi-level verification process including identity checks (Aadhar/PAN), criminal record verification through third-party agencies, and previous employment reference checks.'
  },
  {
    question: 'What if I am not satisfied with the service?',
    answer: 'We offer a satisfaction guarantee. If you are not happy with the service provided, we will provide a free replacement for that session, no questions asked.'
  },
  {
    question: 'Can I book a service for a specific time?',
    answer: 'Yes, our platform allows you to schedule services at your preferred time slots. You can choose from available slots during the booking process.'
  },
  {
    question: 'Are there any hidden charges?',
    answer: 'No, we believe in complete transparency. The price you see on the checkout page is the final price you pay. All taxes and service fees are included.'
  },
  {
    question: 'How do I pay for the service?',
    answer: 'You can pay securely through our app using various methods including UPI, Credit/Debit cards, and Net Banking. We also offer a wallet feature for easy recurring payments.'
  }
];

const FAQItem = ({ faq, isOpen, toggle }: { faq: any, isOpen: boolean, toggle: () => void }) => {
  return (
    <div className="border-b border-gray-100 last:border-0">
      <button
        onClick={toggle}
        className="w-full py-6 flex items-center justify-between text-left hover:text-primary transition-colors duration-300"
      >
        <span className="text-lg font-bold text-secondary">{faq.question}</span>
        <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${isOpen ? 'bg-primary text-white rotate-180' : 'bg-soft-bg text-secondary'}`}>
          {isOpen ? <Minus size={18} /> : <Plus size={18} />}
        </div>
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            <p className="pb-6 text-text-muted leading-relaxed">
              {faq.answer}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-24 bg-white">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-display font-bold text-secondary mb-4"
          >
            Frequently Asked Questions
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-text-muted"
          >
            Everything you need to know about our services and process.
          </motion.p>
        </div>

        <div className="bg-white rounded-[40px] p-8 md:p-12 shadow-2xl border border-gray-50">
          {faqs.map((faq, i) => (
            <FAQItem
              key={i}
              faq={faq}
              isOpen={openIndex === i}
              toggle={() => setOpenIndex(openIndex === i ? null : i)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;
