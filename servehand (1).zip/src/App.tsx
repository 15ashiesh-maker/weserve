import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from './lib/firebase';
import { useStore, User } from './store/useStore';

import Navbar from './components/layout/Navbar';
import Hero from './components/layout/Hero';
import ServicesSection from './components/layout/ServicesSection';
import LocationBanner from './components/layout/LocationBanner';
import HowItWorks from './components/layout/HowItWorks';
import PricingSection from './components/layout/PricingSection';
import WhyUs from './components/layout/WhyUs';
import Testimonials from './components/layout/Testimonials';
import FAQ from './components/layout/FAQ';
import Footer from './components/layout/Footer';

// Pages
import ServicesPage from './pages/ServicesPage';
import HowItWorksPage from './pages/HowItWorksPage';
import PricingPage from './pages/PricingPage';
import WhyUsPage from './pages/WhyUsPage';
import ContactPage from './pages/ContactPage';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import ForgotPasswordPage from './pages/ForgotPasswordPage';
import BookingPage from './pages/BookingPage';
import AboutPage from './pages/AboutPage';
import DeepCleaningPage from './pages/DeepCleaningPage';
import DashboardPage from './pages/DashboardPage';
import MaidDashboardPage from './pages/MaidDashboardPage';
import ServiceProviderOnboardingPage from './pages/ServiceProviderOnboardingPage';
import SearchPage from './pages/SearchPage';
import MaidProfilePage from './pages/MaidProfilePage';
import ServiceShowcase3D from './components/layout/ServiceShowcase3D';

// Placeholder Pages
const HomePage = () => (
  <main>
    <Hero />
    <ServiceShowcase3D />
    <HowItWorks />
    <PricingSection />
    <WhyUs />
    <Testimonials />
    <FAQ />
    <Footer />
    <LocationBanner />
  </main>
);

export default function App() {
  const setUser = useStore((state) => state.setUser);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        // Fetch user document from Firestore
        const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
        if (userDoc.exists()) {
          const userData = userDoc.data() as User;
          setUser({ ...userData, id: firebaseUser.uid });
        } else {
          // Default minimal state until Firestore is updated during signup/login flow
          setUser({
            id: firebaseUser.uid,
            name: firebaseUser.displayName || 'User',
            email: firebaseUser.email || '',
            role: 'user', // Temporary default until user setup handles role selection
          });
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [setUser]);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-soft-bg text-primary font-bold text-xl">Loading ServeHand...</div>;
  }

  return (
    <Router>
      <div className="min-h-screen flex flex-col selection:bg-primary selection:text-white">
        <Navbar />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/how-it-works" element={<HowItWorksPage />} />
          <Route path="/pricing" element={<PricingPage />} />
          <Route path="/why-us" element={<WhyUsPage />} />
          <Route path="/deep-cleaning" element={<DeepCleaningPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/signup" element={<SignupPage />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/maid-dashboard" element={<MaidDashboardPage />} />
          <Route path="/onboarding" element={<ServiceProviderOnboardingPage />} />
          <Route path="/dashboard/book" element={<BookingPage />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/maid/:id" element={<MaidProfilePage />} />
        </Routes>
      </div>
    </Router>
  );
}
