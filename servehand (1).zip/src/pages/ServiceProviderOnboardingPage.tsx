import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import { 
  User, 
  MapPin, 
  Phone, 
  Upload, 
  CheckCircle, 
  ArrowRight, 
  ArrowLeft,
  Shield,
  FileText,
  Users
} from 'lucide-react';
import { useStore } from '../store/useStore';
import { doc, updateDoc } from 'firebase/firestore';
import { db, handleFirestoreError } from '../lib/firebase';

const ServiceProviderOnboardingPage = () => {
  const [step, setStep] = useState(1);
  const { user, setUser } = useStore();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    name: user?.name || '',
    currentAddress: '',
    permanentAddress: '',
    aadharNumber: '',
    phone: user?.phone || '',
    familyDetails: '',
    photo: null as File | null,
    document: null as File | null,
    policeVerification: null as File | null,
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, field: string) => {
    if (e.target.files && e.target.files[0]) {
      setFormData(prev => ({ ...prev, [field]: e.target.files![0] }));
    }
  };

  const nextStep = () => setStep(prev => prev + 1);
  const prevStep = () => setStep(prev => prev - 1);

  const handleSubmit = async () => {
    if (!user) return;
    setIsSubmitting(true);
    try {
      // In a real app we would upload the files to Firebase Storage and get URLs.
      // Here we will just update the user document.
      const userRef = doc(db, 'users', user.id);
      const onboardingData = {
        name: formData.name,
        phone: formData.phone,
        aadharNumber: formData.aadharNumber,
        familyDetails: formData.familyDetails,
        currentAddress: formData.currentAddress,
        permanentAddress: formData.permanentAddress,
        onboardingCompleted: true,
        verificationStatus: {
          'Aadhar Card': (formData.document ? 'pending' : 'not_uploaded') as 'pending' | 'not_uploaded',
          'Police Verification': (formData.policeVerification ? 'pending' : 'not_uploaded') as 'pending' | 'not_uploaded',
          'Profile Photo': (formData.photo ? 'pending' : 'not_uploaded') as 'pending' | 'not_uploaded',
          'Pan Card': 'not_uploaded' as 'not_uploaded',
          'Address Proof': 'not_uploaded' as 'not_uploaded'
        },
        documentUrls: {
          'Aadhar Card': formData.document ? formData.document.name : '',
          'Police Verification': formData.policeVerification ? formData.policeVerification.name : '',
          'Profile Photo': formData.photo ? formData.photo.name : '',
        }
      };

      await updateDoc(userRef, onboardingData).catch(err => handleFirestoreError(err, 'update', `users/${user.id}`, user));
      
      setUser({ ...user, ...onboardingData });
      navigate('/maid-dashboard');
    } catch (error) {
      console.error(error);
      alert('Failed to save profile. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-soft-bg pt-24 pb-12">
      <div className="max-w-3xl mx-auto px-6">
        <div className="text-center mb-12">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-display font-bold text-secondary mb-4"
          >
            Maid & Staff <span className="text-primary">Onboarding</span>
          </motion.h1>
          <p className="text-text-muted">Complete your profile to start receiving service requests.</p>
        </div>

        {/* Progress Bar */}
        <div className="flex justify-between items-center mb-12 relative">
          <div className="absolute top-1/2 left-0 w-full h-1 bg-gray-200 -translate-y-1/2 -z-10"></div>
          <div 
            className="absolute top-1/2 left-0 h-1 bg-primary -translate-y-1/2 -z-10 transition-all duration-500"
            style={{ width: `${((step - 1) / 2) * 100}%` }}
          ></div>
          {[1, 2, 3].map((num) => (
            <div 
              key={num}
              className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all duration-300 ${
                step >= num ? 'bg-primary text-white scale-110 shadow-lg' : 'bg-white text-gray-400 border-2 border-gray-100'
              }`}
            >
              {step > num ? <CheckCircle size={20} /> : num}
            </div>
          ))}
        </div>

        <motion.div 
          className="bg-white p-8 md:p-12 rounded-[40px] shadow-2xl border border-gray-50"
          layout
        >
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <h2 className="text-2xl font-display font-bold text-secondary mb-6 flex items-center gap-2">
                  <User className="text-primary" /> Personal Information
                </h2>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-bold text-secondary uppercase tracking-wider mb-2">Display Name</label>
                    <input 
                      type="text" 
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none transition-all"
                      placeholder="Your full name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-secondary uppercase tracking-wider mb-2">Phone Number</label>
                    <input 
                      type="tel" 
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none transition-all"
                      placeholder="+91 XXXXX XXXXX"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-secondary uppercase tracking-wider mb-2">Aadhar Number</label>
                    <input 
                      type="text" 
                      name="aadharNumber"
                      value={formData.aadharNumber}
                      onChange={handleInputChange}
                      className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none transition-all"
                      placeholder="12-digit Aadhar number"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-secondary uppercase tracking-wider mb-2">Family Details</label>
                    <textarea 
                      name="familyDetails"
                      value={formData.familyDetails}
                      onChange={handleInputChange}
                      rows={3}
                      className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none transition-all resize-none"
                      placeholder="Summary of family members, dependent status etc."
                    />
                  </div>
                </div>

                <div className="pt-6">
                  <button 
                    onClick={nextStep}
                    className="w-full bg-primary text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:scale-[1.02] transition-all shadow-xl shadow-primary/20"
                  >
                    Next Step <ArrowRight size={20} />
                  </button>
                </div>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <h2 className="text-2xl font-display font-bold text-secondary mb-6 flex items-center gap-2">
                  <MapPin className="text-primary" /> Address Details
                </h2>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-bold text-secondary uppercase tracking-wider mb-2">Current Address</label>
                    <textarea 
                      name="currentAddress"
                      value={formData.currentAddress}
                      onChange={handleInputChange}
                      rows={3}
                      className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none transition-all resize-none"
                      placeholder="Enter your current location in Noida/NCR"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-secondary uppercase tracking-wider mb-2">Permanent Address</label>
                    <textarea 
                      name="permanentAddress"
                      value={formData.permanentAddress}
                      onChange={handleInputChange}
                      rows={3}
                      className="w-full px-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none transition-all resize-none"
                      placeholder="As mentioned on your documents"
                    />
                  </div>
                </div>

                <div className="flex gap-4 pt-6">
                  <button 
                    onClick={prevStep}
                    className="flex-1 bg-gray-100 text-secondary py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-gray-200 transition-all font-bold"
                  >
                    <ArrowLeft size={20} /> Back
                  </button>
                  <button 
                    onClick={nextStep}
                    className="flex-[2] bg-primary text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:scale-[1.02] transition-all shadow-xl shadow-primary/20"
                  >
                    Next Step <ArrowRight size={20} />
                  </button>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <h2 className="text-2xl font-display font-bold text-secondary mb-6 flex items-center gap-2">
                  <Shield className="text-primary" /> Verification Documents
                </h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Photo Upload */}
                  <div className="p-6 border-2 border-dashed border-gray-200 rounded-3xl hover:border-primary transition-colors flex flex-col items-center text-center">
                    <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary mb-4">
                      <User size={24} />
                    </div>
                    <label className="cursor-pointer">
                      <input type="file" className="hidden" onChange={(e) => handleFileChange(e, 'photo')} />
                      <p className="font-bold text-secondary mb-1">Passport Photo</p>
                      <p className="text-xs text-text-muted mb-4">Click to upload JPG/PNG</p>
                      {formData.photo && <span className="text-xs text-primary font-bold">{formData.photo.name}</span>}
                    </label>
                  </div>

                  {/* Document Upload */}
                  <div className="p-6 border-2 border-dashed border-gray-200 rounded-3xl hover:border-primary transition-colors flex flex-col items-center text-center">
                    <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary mb-4">
                      <FileText size={24} />
                    </div>
                    <label className="cursor-pointer">
                      <input type="file" className="hidden" onChange={(e) => handleFileChange(e, 'document')} />
                      <p className="font-bold text-secondary mb-1">Aadhar/ID Copy</p>
                      <p className="text-xs text-text-muted mb-4">Front & Back scan</p>
                      {formData.document && <span className="text-xs text-primary font-bold">{formData.document.name}</span>}
                    </label>
                  </div>

                  {/* Police Verification */}
                  <div className="p-6 border-2 border-dashed border-gray-200 rounded-3xl hover:border-primary transition-colors flex flex-col items-center text-center md:col-span-2">
                    <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary mb-4">
                      <Shield size={24} />
                    </div>
                    <label className="cursor-pointer">
                      <input type="file" className="hidden" onChange={(e) => handleFileChange(e, 'policeVerification')} />
                      <p className="font-bold text-secondary mb-1">Police Verification</p>
                      <p className="text-xs text-text-muted mb-4">Certificate or applied acknowledgment</p>
                      {formData.policeVerification && <span className="text-xs text-primary font-bold">{formData.policeVerification.name}</span>}
                    </label>
                  </div>
                </div>

                <div className="flex gap-4 pt-6">
                  <button 
                    onClick={prevStep}
                    className="flex-1 bg-gray-100 text-secondary py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-gray-200 transition-all font-bold"
                  >
                    <ArrowLeft size={20} /> Back
                  </button>
                  <button 
                    onClick={handleSubmit}
                    disabled={isSubmitting}
                    className="flex-[2] bg-primary text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:scale-[1.02] transition-all shadow-xl shadow-primary/20"
                  >
                    {isSubmitting ? 'Finalizing...' : 'Complete Onboarding'} <ArrowRight size={20} />
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  );
};

export default ServiceProviderOnboardingPage;
