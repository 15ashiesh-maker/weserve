import React from 'react';
import { motion } from 'motion/react';
import ServicesSection from '../components/layout/ServicesSection';
import Footer from '../components/layout/Footer';
import { Shield, Clock, Heart, Star } from 'lucide-react';

const ServicesPage = () => {
  return (
    <div className="pt-24">
      <section className="bg-secondary py-20 text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-primary/10 skew-x-12 translate-x-1/4" />
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-6xl font-display font-bold mb-6"
          >
            Our Professional <span className="text-primary">Services</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-gray-300 max-w-2xl"
          >
            From daily chores to specialized care, we provide verified and trained professionals 
            to make your life easier and your home happier.
          </motion.p>
        </div>
      </section>

      <ServicesSection />

      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            {[
              { icon: <Shield className="text-primary" size={40} />, title: 'Verified Staff', desc: 'Every helper is background checked and verified.' },
              { icon: <Clock className="text-primary" size={40} />, title: 'On-Time Service', desc: 'Punctuality is our priority. We value your time.' },
              { icon: <Star className="text-primary" size={40} />, title: 'Quality Assured', desc: 'Trained professionals for the best service quality.' },
              { icon: <Heart className="text-primary" size={40} />, title: 'Caring Approach', desc: 'Compassionate care for your loved ones and pets.' },
            ].map((item, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center space-y-4"
              >
                <div className="flex justify-center">{item.icon}</div>
                <h3 className="text-xl font-bold text-secondary">{item.title}</h3>
                <p className="text-text-muted">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default ServicesPage;
