import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { User } from '../store/useStore';
import Navbar from '../components/layout/Navbar';
import Footer from '../components/layout/Footer';
import { 
  Star, 
  MapPin, 
  ShieldCheck, 
  Search, 
  Filter,
  Users,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { useNavigate } from 'react-router-dom';

const SearchPage = () => {
  const [maids, setMaids] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchMaids = async () => {
      try {
        const q = query(collection(db, 'users'), where('role', '==', 'maid'));
        const querySnapshot = await getDocs(q);
        const maidList = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as User));
        setMaids(maidList);
      } catch (error) {
        console.error("Error fetching maids:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchMaids();
  }, []);

  const filteredMaids = maids.filter(maid => 
    maid.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    maid.city?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-soft-bg min-h-screen">
      <Navbar />
      
      <div className="pt-32 pb-20 px-6 max-w-7xl mx-auto">
        <div className="mb-12 space-y-6">
          <div className="max-w-2xl">
            <h1 className="text-5xl font-display font-bold text-secondary mb-4">
              Find Your Perfect <span className="text-primary">Service Pro</span>
            </h1>
            <p className="text-xl text-text-muted">
              Browse through our community of verified, highly-rated professionals ready to help you.
            </p>
          </div>

          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <input 
                type="text" 
                placeholder="Search by name or city..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-14 pr-6 py-4 bg-white rounded-2xl border-none shadow-sm focus:ring-2 focus:ring-primary outline-none font-medium"
              />
            </div>
            <Button className="h-14 px-8 rounded-2xl gap-2 font-bold shadow-lg shadow-primary/20">
              <Filter size={20} /> Filters
            </Button>
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} className="bg-white h-80 rounded-[40px] animate-pulse" />
            ))}
          </div>
        ) : filteredMaids.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredMaids.map((maid) => (
              <motion.div
                key={maid.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                whileHover={{ y: -5 }}
              >
                <Card className="rounded-[40px] border-none shadow-xl hover:shadow-2xl transition-all overflow-hidden bg-white h-full flex flex-col">
                  <div className="p-8 flex-1 space-y-6">
                    <div className="flex justify-between items-start">
                      <div className="w-20 h-20 bg-soft-bg rounded-3xl overflow-hidden border-2 border-primary/10">
                        {maid.photoUrl ? (
                          <img src={maid.photoUrl} alt={maid.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-primary bg-primary/5">
                            <Users size={32} />
                          </div>
                        )}
                      </div>
                      <Badge className="bg-green-100 text-green-700 hover:bg-green-100 border-none font-bold gap-1 px-3 py-1 rounded-full">
                        <ShieldCheck size={14} /> Verified
                      </Badge>
                    </div>

                    <div>
                      <h3 className="text-2xl font-bold text-secondary mb-1">{maid.name}</h3>
                      <p className="text-text-muted flex items-center gap-1 text-sm font-medium">
                        <MapPin size={14} className="text-primary" /> {maid.city || 'Available Nationwide'}
                      </p>
                    </div>

                    <div className="flex items-center gap-4 py-2 border-y border-gray-50">
                      <div className="flex items-center gap-1.5">
                        <Star size={18} className="text-yellow-400 fill-current" />
                        <span className="font-bold text-secondary text-lg">{maid.averageRating || 'New'}</span>
                      </div>
                      <div className="h-4 w-[1px] bg-gray-200" />
                      <div className="text-sm text-text-muted font-medium">
                        <span className="text-secondary font-bold">{maid.reviewCount || 0}</span> Reviews
                      </div>
                    </div>

                    <div className="space-y-3">
                      <p className="text-xs font-bold text-text-muted uppercase tracking-widest">Top Services</p>
                      <div className="flex flex-wrap gap-2">
                        {['Cleaning', 'Cooking'].map(s => (
                          <Badge key={s} variant="outline" className="rounded-lg font-medium text-[10px] uppercase tracking-tighter">
                            {s}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="p-8 pt-0">
                    <Button 
                      onClick={() => navigate(`/maid/${maid.id}`)}
                      className="w-full py-6 rounded-2xl font-bold text-lg group bg-secondary hover:bg-secondary/90"
                    >
                      View Profile <ChevronRight className="ml-2 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white rounded-[40px] shadow-sm">
            <div className="w-20 h-20 bg-primary/5 rounded-full flex items-center justify-center mx-auto mb-6">
              <Search size={40} className="text-primary opacity-20" />
            </div>
            <h3 className="text-2xl font-bold text-secondary mb-2">No professionals found</h3>
            <p className="text-text-muted">Try adjusting your search or filters.</p>
          </div>
        )}

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-20 p-12 bg-secondary rounded-[50px] relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <Sparkles size={120} className="text-white" />
          </div>
          <div className="max-w-2xl relative z-10">
            <h2 className="text-4xl font-display font-bold text-white mb-6">Join our community of pros</h2>
            <p className="text-white/70 text-lg mb-8">
              Are you a skilled service provider looking for more work? Become a verified partner on MaidEase today.
            </p>
            <Button onClick={() => navigate('/onboarding')} className="bg-primary text-white hover:bg-primary/90 px-10 py-6 rounded-2xl font-bold text-lg">
              Apply as a Pro
            </Button>
          </div>
        </motion.div>
      </div>

      <Footer />
    </div>
  );
};

export default SearchPage;
