import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Phone, MapPin, Mail, Lock, User as UserIcon } from 'lucide-react';
import { auth, db, handleFirestoreError } from '../lib/firebase';
import { signInWithPopup, GoogleAuthProvider, createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { z } from 'zod';

const signupSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Invalid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  phone: z.string().min(10, 'Phone must be at least 10 digits'),
  city: z.string().min(1, 'Please select a city'),
  role: z.enum(['user', 'maid'])
});

const SignupPage = () => {
  const [step, setStep] = useState(1);
  const [method, setMethod] = useState<'google' | 'email'>('google');
  const [isLoading, setIsLoading] = useState(false);
  const [errorText, setErrorText] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    city: '',
    role: 'user' as 'user' | 'maid'
  });

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setErrorText('');
    setErrors({});
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      
      const userRef = doc(db, 'users', result.user.uid);
      const docSnap = await getDoc(userRef);
      
      if (docSnap.exists()) {
        const userData = docSnap.data();
        navigate(userData.role === 'maid' ? '/maid-dashboard' : '/dashboard');
      } else {
        setMethod('google');
        setStep(2);
      }
    } catch (error: any) {
      console.error(error);
      setErrorText(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEmailSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorText('');
    setErrors({});

    try {
      // Validate with Zod
      signupSchema.parse(formData);
      
      const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
      await updateProfile(userCredential.user, { displayName: formData.name });

      const userRef = doc(db, 'users', userCredential.user.uid);
      await setDoc(userRef, {
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        city: formData.city,
        role: formData.role,
        notificationPreferences: {
          pushNotifications: true,
          emailAlerts: true
        },
        ...(formData.role === 'maid' ? { onboardingCompleted: false } : {}),
        createdAt: new Date().toISOString()
      }).catch(err => handleFirestoreError(err, 'create', `users/${userCredential.user.uid}`, userCredential.user));

      navigate(formData.role === 'maid' ? '/onboarding' : '/dashboard');
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        const newErrors: Record<string, string> = {};
        error.issues.forEach((err) => {
          if (err.path[0]) newErrors[err.path[0].toString()] = err.message;
        });
        setErrors(newErrors);
      } else {
        console.error(error);
        setErrorText(error.message || 'Could not create account.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleCompleteGoogleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    
    setIsLoading(true);
    setErrorText('');
    setErrors({});
    
    try {
      // Validate partial data for Google signup step 2
      const partialData = {
        name: auth.currentUser.displayName || 'User',
        email: auth.currentUser.email || '',
        password: 'dummy-password-for-validation', // Not used for Google
        phone: formData.phone,
        city: formData.city,
        role: formData.role
      };
      signupSchema.parse(partialData);
      
      const userRef = doc(db, 'users', auth.currentUser.uid);
      await setDoc(userRef, {
        name: auth.currentUser.displayName || 'User',
        email: auth.currentUser.email || '',
        phone: formData.phone,
        city: formData.city,
        role: formData.role,
        notificationPreferences: {
          pushNotifications: true,
          emailAlerts: true
        },
        ...(formData.role === 'maid' ? { onboardingCompleted: false } : {}),
        createdAt: new Date().toISOString()
      }).catch(err => handleFirestoreError(err, 'create', `users/${auth.currentUser?.uid}`, auth.currentUser));
      
      navigate(formData.role === 'maid' ? '/onboarding' : '/dashboard');
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        const newErrors: Record<string, string> = {};
        error.issues.forEach((err) => {
          if (err.path[0]) newErrors[err.path[0].toString()] = err.message;
        });
        setErrors(newErrors);
      } else {
        console.error(error);
        setErrorText('Could not complete signup. Please check your data.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-soft-bg px-6 py-32 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(#1E1B4B_1px,transparent_1px)] [background-size:40px_40px]" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="bg-white p-10 md:p-12 rounded-[40px] shadow-2xl border border-gray-50">
          <div className="text-center mb-10">
            <Link to="/" className="inline-flex items-center gap-2 mb-6 group">
              <div className="w-12 h-12 bg-primary rounded-2xl flex items-center justify-center text-white font-bold text-2xl shadow-lg group-hover:scale-110 transition-transform">
                SH
              </div>
              <span className="font-display text-3xl font-bold tracking-tight text-secondary">
                Serve<span className="text-primary">Hand</span>
              </span>
            </Link>
            <h1 className="text-3xl font-display font-bold text-secondary mb-2">
              {step === 1 ? 'Create Account' : 'Complete Profile'}
            </h1>
            <p className="text-text-muted">
              {step === 1 ? 'Join ServeHand and simplify your life.' : 'Just a few more details to get started.'}
            </p>
          </div>

          {errorText && (
            <div className="bg-red-50 text-red-600 p-3 rounded-lg mb-6 text-sm text-center">
              {errorText}
            </div>
          )}

          <AnimatePresence mode="wait">
            {step === 1 ? (
              <motion.div 
                key="step1"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="space-y-6" 
              >
                <div className="flex bg-soft-bg p-1 rounded-2xl mb-8">
                  <button 
                    onClick={() => setFormData({...formData, role: 'user'})}
                    className={`flex-1 py-3 rounded-xl font-bold transition-all ${formData.role === 'user' ? 'bg-primary text-white shadow-lg' : 'text-text-muted hover:text-primary'}`}
                  >
                    Customer
                  </button>
                  <button 
                    onClick={() => setFormData({...formData, role: 'maid'})}
                    className={`flex-1 py-3 rounded-xl font-bold transition-all ${formData.role === 'maid' ? 'bg-primary text-white shadow-lg' : 'text-text-muted hover:text-primary'}`}
                  >
                    Maid / Staff
                  </button>
                </div>

                <div className="space-y-4">
                  <button 
                    onClick={handleGoogleSignIn}
                    disabled={isLoading}
                    className="w-full bg-white border-2 border-gray-100 text-secondary py-4 rounded-2xl font-bold text-lg shadow-sm hover:bg-gray-50 hover:border-gray-200 transition-all flex items-center justify-center gap-3"
                  >
                    <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-6 h-6" />
                    {isLoading ? 'Connecting...' : 'Sign up with Google'}
                  </button>

                  <div className="relative flex items-center justify-center py-2">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-gray-100"></div>
                    </div>
                    <span className="relative bg-white px-4 text-xs font-bold text-text-muted uppercase">or</span>
                  </div>

                  <button 
                    onClick={() => {
                      setMethod('email');
                      setStep(2);
                    }}
                    disabled={isLoading}
                    className="w-full bg-primary/10 text-primary py-4 rounded-2xl font-bold text-lg hover:bg-primary/20 transition-all flex items-center justify-center gap-3"
                  >
                    <Mail size={20} />
                    Sign up with Email
                  </button>
                </div>
              </motion.div>
            ) : (
              <motion.form 
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
                onSubmit={method === 'email' ? handleEmailSignupSubmit : handleCompleteGoogleSignup}
              >
                {method === 'email' && (
                  <>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-secondary uppercase tracking-wider ml-1">Full Name</label>
                      <div className="relative">
                        <UserIcon className={`absolute left-5 top-1/2 -translate-y-1/2 ${errors.name ? 'text-red-400' : 'text-gray-400'}`} size={18} />
                        <input 
                          type="text" 
                          placeholder="John Doe" 
                          value={formData.name}
                          onChange={(e) => setFormData({...formData, name: e.target.value})}
                          className={`w-full pl-12 pr-6 py-3.5 bg-soft-bg rounded-2xl border-2 outline-none transition-all font-medium ${errors.name ? 'border-red-100 focus:border-red-200' : 'border-transparent focus:border-primary'}`}
                        />
                      </div>
                      {errors.name && <p className="text-[10px] text-red-500 font-bold ml-1">{errors.name}</p>}
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-secondary uppercase tracking-wider ml-1">Email Address</label>
                      <div className="relative">
                        <Mail className={`absolute left-5 top-1/2 -translate-y-1/2 ${errors.email ? 'text-red-400' : 'text-gray-400'}`} size={18} />
                        <input 
                          type="email" 
                          placeholder="john@example.com" 
                          value={formData.email}
                          onChange={(e) => setFormData({...formData, email: e.target.value})}
                          className={`w-full pl-12 pr-6 py-3.5 bg-soft-bg rounded-2xl border-2 outline-none transition-all font-medium ${errors.email ? 'border-red-100 focus:border-red-200' : 'border-transparent focus:border-primary'}`}
                        />
                      </div>
                      {errors.email && <p className="text-[10px] text-red-500 font-bold ml-1">{errors.email}</p>}
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-secondary uppercase tracking-wider ml-1">Password</label>
                      <div className="relative">
                        <Lock className={`absolute left-5 top-1/2 -translate-y-1/2 ${errors.password ? 'text-red-400' : 'text-gray-400'}`} size={18} />
                        <input 
                          type="password" 
                          placeholder="••••••••" 
                          value={formData.password}
                          onChange={(e) => setFormData({...formData, password: e.target.value})}
                          className={`w-full pl-12 pr-6 py-3.5 bg-soft-bg rounded-2xl border-2 outline-none transition-all font-medium ${errors.password ? 'border-red-100 focus:border-red-200' : 'border-transparent focus:border-primary'}`}
                        />
                      </div>
                      {errors.password && <p className="text-[10px] text-red-500 font-bold ml-1">{errors.password}</p>}
                    </div>
                  </>
                )}

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-secondary uppercase tracking-wider ml-1">Phone Number</label>
                  <div className="relative">
                    <Phone className={`absolute left-5 top-1/2 -translate-y-1/2 ${errors.phone ? 'text-red-400' : 'text-gray-400'}`} size={18} />
                    <input 
                      type="tel" 
                      placeholder="+91 98765 43210" 
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      className={`w-full pl-12 pr-6 py-3.5 bg-soft-bg rounded-2xl border-2 outline-none transition-all font-medium ${errors.phone ? 'border-red-100 focus:border-red-200' : 'border-transparent focus:border-primary'}`}
                    />
                  </div>
                  {errors.phone && <p className="text-[10px] text-red-500 font-bold ml-1">{errors.phone}</p>}
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-secondary uppercase tracking-wider ml-1">City</label>
                  <div className="relative">
                    <MapPin className={`absolute left-5 top-1/2 -translate-y-1/2 ${errors.city ? 'text-red-400' : 'text-gray-400'}`} size={18} />
                    <select 
                      value={formData.city}
                      onChange={(e) => setFormData({...formData, city: e.target.value})}
                      className={`w-full pl-12 pr-6 py-3.5 bg-soft-bg rounded-2xl border-2 outline-none transition-all font-medium appearance-none ${errors.city ? 'border-red-100 focus:border-red-200' : 'border-transparent focus:border-primary'}`}
                    >
                      <option value="">Select your city</option>
                      <option value="Noida">Noida</option>
                      <option value="Delhi">Delhi</option>
                      <option value="Bangalore">Bangalore</option>
                      <option value="Gurugram">Gurugram</option>
                    </select>
                  </div>
                  {errors.city && <p className="text-[10px] text-red-500 font-bold ml-1">{errors.city}</p>}
                </div>

                <div className="pt-2 flex flex-col gap-3">
                  <button 
                    disabled={isLoading}
                    className="w-full bg-secondary text-white py-4 rounded-2xl font-bold text-lg shadow-xl hover:bg-secondary/90 transition-all disabled:opacity-50"
                  >
                    {isLoading ? (method === 'google' ? 'Completing...' : 'Creating Account...') : (method === 'google' ? 'Complete Signup' : 'Create Account')}
                  </button>
                  <button 
                    type="button"
                    onClick={() => {
                      setStep(1);
                      setMethod('google');
                      setErrors({});
                    }}
                    className="text-sm font-bold text-text-muted hover:text-secondary py-2"
                  >
                    Go Back
                  </button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>

          <p className="text-center mt-10 text-text-muted font-medium">
            Already have an account? <Link to="/login" className="text-primary font-bold hover:underline">Log In</Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
};

export default SignupPage;
