import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { Mail, ArrowLeft, Send, CheckCircle } from 'lucide-react';
import { auth } from '../lib/firebase';
import { sendPasswordResetEmail } from 'firebase/auth';

const ForgotPasswordPage = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorText, setErrorText] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorText('');
    
    try {
      await sendPasswordResetEmail(auth, email);
      setSubmitted(true);
    } catch (error: any) {
      console.error(error);
      if (error.code === 'auth/user-not-found') {
        setErrorText('No account found with this email address.');
      } else {
        setErrorText(error.message || 'Failed to send reset link. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-soft-bg px-6 py-32 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(#1E1B4B_1px,transparent_1px)] [background-size:40px_40px]" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="bg-white p-10 md:p-12 rounded-[40px] shadow-2xl border border-gray-50">
          <div className="text-center mb-10">
            <Link to="/" className="inline-flex items-center gap-2 mb-6 group">
              <div className="w-12 h-12 bg-primary rounded-2xl flex items-center justify-center text-white font-bold text-2xl shadow-lg group-hover:scale-110 transition-transform">
                SH
              </div>
              <span className="font-display text-3xl font-bold tracking-tight text-secondary">
                Serve<span className="text-primary">Hand</span>
              </span>
            </Link>
            <h1 className="text-3xl font-display font-bold text-secondary mb-2">
              {submitted ? 'Check Your Email' : 'Reset Password'}
            </h1>
            <p className="text-text-muted">
              {submitted 
                ? 'We have sent a password reset link to your email address.' 
                : 'Enter your email address and we will send you a link to reset your password.'}
            </p>
          </div>

          {errorText && (
            <div className="bg-red-50 text-red-600 p-3 rounded-lg mb-6 text-sm text-center">
              {errorText}
            </div>
          )}

          {!submitted ? (
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div className="space-y-2">
                <label className="text-sm font-bold text-secondary uppercase tracking-wider">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                  <input 
                    type="email" 
                    placeholder="john@example.com" 
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-14 pr-6 py-4 bg-soft-bg rounded-2xl border-2 border-transparent focus:border-primary outline-none transition-all font-medium"
                  />
                </div>
              </div>

              <button 
                disabled={isLoading}
                className="w-full bg-primary text-white py-5 rounded-2xl font-bold text-lg shadow-xl hover:bg-primary/90 transition-all flex items-center justify-center gap-3 group disabled:opacity-50"
              >
                {isLoading ? 'Sending...' : 'Send Reset Link'}
                {!isLoading && <Send size={20} className="group-hover:translate-x-1 transition-transform" />}
              </button>
            </form>
          ) : (
            <div className="space-y-8 text-center">
              <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center text-primary mx-auto">
                <CheckCircle size={40} />
              </div>
              <p className="text-secondary font-medium">
                Didn't receive the email? <button onClick={() => setSubmitted(false)} className="text-primary font-bold hover:underline">Try again</button>
              </p>
            </div>
          )}

          <div className="mt-10 pt-10 border-t border-gray-100 text-center">
            <Link to="/login" className="inline-flex items-center gap-2 text-secondary font-bold hover:text-primary transition-colors">
              <ArrowLeft size={20} />
              Back to Login
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default ForgotPasswordPage;
