import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { doc, getDoc, collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { User, Review } from '../store/useStore';
import Navbar from '../components/layout/Navbar';
import Footer from '../components/layout/Footer';
import { 
  Star, 
  MapPin, 
  ShieldCheck, 
  Calendar, 
  Clock,
  ChevronLeft,
  Quote,
  TrendingUp,
  Award
} from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { format } from 'date-fns';

const MaidProfilePage = () => {
  const { id } = useParams<{ id: string }>();
  const [maid, setMaid] = useState<User | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchMaidData = async () => {
      if (!id) return;
      try {
        // Fetch Maid
        const maidDoc = await getDoc(doc(db, 'users', id));
        if (maidDoc.exists()) {
          setMaid({ id: maidDoc.id, ...maidDoc.data() } as User);
        }

        // Fetch Reviews
        const reviewsQuery = query(
          collection(db, 'reviews'), 
          where('maidId', '==', id),
          orderBy('createdAt', 'desc')
        );
        const reviewsSnapshot = await getDocs(reviewsQuery);
        const reviewsList = reviewsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Review));
        setReviews(reviewsList);
      } catch (error) {
        console.error("Error fetching maid profile:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchMaidData();
  }, [id]);

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-soft-bg text-primary font-bold">Loading Profile...</div>;
  if (!maid) return <div className="min-h-screen flex items-center justify-center bg-soft-bg text-secondary font-bold">Profile not found.</div>;

  return (
    <div className="bg-soft-bg min-h-screen">
      <Navbar />

      <div className="pt-32 pb-20 px-6 max-w-7xl mx-auto">
        <button 
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-text-muted hover:text-primary font-bold mb-8 transition-colors group"
        >
          <ChevronLeft className="group-hover:-translate-x-1 transition-transform" /> Back to Search
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-12">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white p-8 md:p-12 rounded-[50px] shadow-xl relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-8">
                <Badge className="bg-primary/10 text-primary border-none rounded-full px-4 py-2 font-bold gap-2">
                  <Award size={16} /> Top Verified Pro
                </Badge>
              </div>

              <div className="flex flex-col md:flex-row gap-10 items-start md:items-center mb-12">
                <div className="w-40 h-40 rounded-[40px] bg-soft-bg border-4 border-white shadow-xl overflow-hidden shrink-0">
                  {maid.photoUrl ? (
                    <img src={maid.photoUrl} alt={maid.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-primary/5 text-primary text-5xl">
                      {maid.name.charAt(0)}
                    </div>
                  )}
                </div>
                <div className="space-y-4">
                  <div className="space-y-1">
                    <h1 className="text-4xl font-display font-bold text-secondary">{maid.name}</h1>
                    <div className="flex items-center gap-2 text-text-muted font-medium">
                      <MapPin size={18} className="text-primary" /> {maid.city || 'Available Nationwide'}
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="flex flex-col">
                      <div className="flex items-center gap-1">
                        <Star size={20} className="text-yellow-400 fill-current" />
                        <span className="text-2xl font-bold text-secondary">{maid.averageRating || 'New'}</span>
                      </div>
                      <span className="text-xs text-text-muted font-bold uppercase tracking-widest">{maid.reviewCount || 0} Reviews</span>
                    </div>
                    <div className="h-10 w-[1px] bg-gray-100" />
                    <div>
                      <div className="text-2xl font-bold text-secondary">100+</div>
                      <span className="text-xs text-text-muted font-bold uppercase tracking-widest">Bookings</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 py-8 border-t border-gray-100">
                <div className="space-y-4">
                  <h3 className="text-lg font-bold text-secondary">Experience & Skills</h3>
                  <div className="flex flex-wrap gap-2">
                    {['Deep Cleaning', 'Cooking', 'Elderly Care', 'Organization', 'Punctual'].map(skill => (
                      <Badge key={skill} className="bg-soft-bg text-secondary border-none px-3 py-1 rounded-lg">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="space-y-4">
                  <h3 className="text-lg font-bold text-secondary">Verified Details</h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 text-sm text-text-muted font-medium">
                      <ShieldCheck className="text-green-500" size={18} /> Police Verified Background
                    </div>
                    <div className="flex items-center gap-3 text-sm text-text-muted font-medium">
                      <ShieldCheck className="text-green-500" size={18} /> Identity Documents Verified
                    </div>
                    <div className="flex items-center gap-3 text-sm text-text-muted font-medium">
                      <ShieldCheck className="text-green-500" size={18} /> Health Check Cleared
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Reviews Section */}
            <div className="space-y-8">
              <h2 className="text-3xl font-display font-bold text-secondary flex items-center justify-between">
                Customer Reviews 
                <span className="text-sm font-bold bg-white text-primary px-4 py-2 rounded-full border border-gray-100">
                  {reviews.length} total
                </span>
              </h2>
              
              {reviews.length > 0 ? (
                <div className="grid gap-6">
                  {reviews.map((review, index) => (
                    <motion.div
                      key={review.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <Card className="rounded-[32px] border-none shadow-lg p-8 space-y-6 relative hover:shadow-xl transition-shadow bg-white">
                        <Quote className="absolute top-8 right-8 text-primary/5" size={60} />
                        <div className="flex justify-between items-start">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary font-bold text-xl">
                              {review.customerName.charAt(0)}
                            </div>
                            <div>
                              <h4 className="font-bold text-secondary">{review.customerName}</h4>
                              <p className="text-xs text-text-muted font-medium">{format(new Date(review.createdAt), 'MMMM dd, yyyy')}</p>
                            </div>
                          </div>
                          <div className="flex gap-1">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} size={14} className={i < review.rating ? 'text-yellow-400 fill-current' : 'text-gray-200'} />
                            ))}
                          </div>
                        </div>
                        <p className="text-secondary leading-relaxed font-medium italic relative z-10">
                          "{review.comment}"
                        </p>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="bg-white p-12 rounded-[40px] text-center border-2 border-dashed border-gray-100">
                  <p className="text-text-muted italic">No reviews yet for this professional.</p>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-8">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-secondary p-8 rounded-[40px] text-white shadow-2xl sticky top-32"
            >
              <h3 className="text-2xl font-display font-bold mb-6 flex items-center gap-2">
                <TrendingUp className="text-primary" size={24} /> Availability
              </h3>
              <div className="space-y-6">
                <div className="bg-white/5 p-4 rounded-2xl border border-white/10 flex items-center gap-4">
                  <Calendar className="text-primary" size={24} />
                  <div>
                    <p className="text-xs font-bold text-white/50 uppercase tracking-widest">Next Available</p>
                    <p className="font-bold">Tomorrow, 09:00 AM</p>
                  </div>
                </div>
                <div className="bg-white/5 p-4 rounded-2xl border border-white/10 flex items-center gap-4">
                  <Clock className="text-primary" size={24} />
                  <div>
                    <p className="text-xs font-bold text-white/50 uppercase tracking-widest">Working Hours</p>
                    <p className="font-bold">Mon - Sat, 08:00 - 18:00</p>
                  </div>
                </div>
                
                <hr className="border-white/10" />

                <div className="space-y-4">
                  <p className="text-sm text-white/70 leading-relaxed">
                    Booking this professional ensures you get consistent, high-quality service from someone the community trusts.
                  </p>
                  <Button 
                    onClick={() => navigate('/dashboard/book')}
                    className="w-full py-8 rounded-2xl text-lg font-bold shadow-xl shadow-primary/20"
                  >
                    Book Now
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default MaidProfilePage;
