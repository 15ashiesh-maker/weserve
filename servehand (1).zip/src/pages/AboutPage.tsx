import React from 'react';
import { motion } from 'motion/react';
import Footer from '../components/layout/Footer';
import { Users, Target, Award, ShieldCheck } from 'lucide-react';

const AboutPage = () => {
  const cofounders = [
    {
      name: 'Ashish Rastogi',
      role: 'Co-Founder',
      image: 'https://i.pravatar.cc/400?u=servehand',
      bio: 'Visionary leader with over 15 years of experience in service industry operations. Ashish is the driving force behind the strategic growth and long-term vision of ServeHand.'
    },
    {
      name: 'Nishant Tyagi',
      role: 'Co-Founder | Operation Expert & Head',
      image: 'https://i.pravatar.cc/400?u=servehand',
      bio: 'A seasoned operations specialist dedicated to optimizing service delivery. Nishant ensures every ServeHand professional meets our rigorous quality standards through streamlined processes and expert management.'
    },
    {
      name: 'Atul Tiwari',
      role: 'Co-Founder | Marketing Expert & Head',
      image: 'https://i.pravatar.cc/400?u=servehand',
      bio: 'A marketing visionary who bridges the gap between ServeHand\'s services and the families who need them most. Atul leads our brand strategy and customer engagement initiatives with data-driven storytelling.'
    }
  ];

  return (
    <div className="pt-24">
      {/* Hero Section */}
      <section className="bg-secondary py-24 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-primary/10 skew-x-12 translate-x-1/4" />
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <h1 className="text-5xl md:text-7xl font-display font-bold mb-8">
              Redefining <span className="text-primary">Home Care</span> in India
            </h1>
            <p className="text-xl text-white/80 leading-relaxed">
              ServeHand was born out of a simple need: to bring reliability, safety, and 
              professionalism to the fragmented home service industry. We connect 
              households with verified, trained, and compassionate helpers.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 text-primary rounded-full font-bold text-sm uppercase tracking-widest">
                <Target size={16} />
                Our Mission
              </div>
              <h2 className="text-4xl font-display font-bold text-secondary">
                Empowering Homes, <br />Elevating Lives
              </h2>
              <p className="text-lg text-text-muted leading-relaxed">
                Our mission is twofold: to provide urban households with a stress-free 
                living experience through professional help, and to provide our workers 
                with dignified employment, fair wages, and a secure future.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div className="p-6 bg-soft-bg rounded-3xl border border-gray-100">
                  <h3 className="text-3xl font-bold text-primary mb-1">10k+</h3>
                  <p className="text-sm font-bold text-secondary uppercase tracking-wider">Happy Homes</p>
                </div>
                <div className="p-6 bg-soft-bg rounded-3xl border border-gray-100">
                  <h3 className="text-3xl font-bold text-primary mb-1">500+</h3>
                  <p className="text-sm font-bold text-secondary uppercase tracking-wider">Verified Staff</p>
                </div>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative"
            >
              <img 
                src="https://images.unsplash.com/photo-1581578731548-c64695cc6958?auto=format&fit=crop&w=800&q=80" 
                alt="Our Team" 
                className="rounded-[40px] shadow-2xl"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-10 -left-10 bg-white p-8 rounded-3xl shadow-2xl border border-gray-100 hidden md:block">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center text-accent">
                    <ShieldCheck size={24} />
                  </div>
                  <div>
                    <p className="font-bold text-secondary">100% Verified</p>
                    <p className="text-sm text-text-muted">Background Checked</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Co-Founders Section */}
      <section className="py-24 bg-soft-bg">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-display font-bold text-secondary mb-4">Meet Our Founders</h2>
            <p className="text-text-muted max-w-2xl mx-auto">
              The driving force behind ServeHand's commitment to excellence and innovation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {cofounders.map((founder, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white p-8 rounded-[40px] shadow-xl border border-gray-50 text-center group"
              >
                <div className="relative mb-8 inline-block">
                  <div className="w-48 h-48 rounded-full overflow-hidden border-4 border-primary/20 group-hover:border-primary transition-colors">
                    <img 
                      src={founder.image} 
                      alt={founder.name} 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="absolute -bottom-2 -right-2 w-12 h-12 bg-secondary rounded-full flex items-center justify-center text-white shadow-lg">
                    <Award size={20} />
                  </div>
                </div>
                <h3 className="text-2xl font-display font-bold text-secondary mb-1">{founder.name}</h3>
                <p className="text-primary font-bold text-sm uppercase tracking-widest mb-4">{founder.role}</p>
                <p className="text-text-muted leading-relaxed">{founder.bio}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default AboutPage;
